<?php
// GlobeForge Services Catalog Management
// File: admin_services.php

require_once 'config.php';
authorize(['admin']);

$error = null;
$success = null;

// Handle Delete Service Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $service_id = intval($_POST['service_id'] ?? 0);
    if ($service_id > 0) {
        try {
            $stmt = $pdo->prepare('DELETE FROM services WHERE service_id = ?');
            $stmt->execute([$service_id]);
            setFlashNotice('success', 'Service deleted successfully.');
            header('Location: admin_services.php');
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() == '23000') {
                $error = 'Cannot delete service. There are active service requests linked to this service.';
            } else {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Handle Add / Edit Service POST Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    $service_id = intval($_POST['service_id'] ?? 0);
    $service_name = trim($_POST['service_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = $_POST['price'] !== '' ? floatval($_POST['price']) : null;
    $status = $_POST['status'] ?? 'active';
    
    if (empty($service_name)) {
        $error = 'Service Name is required.';
    } else {
        try {
            if ($service_id > 0) {
                // Update
                $stmt = $pdo->prepare('
                    UPDATE services 
                    SET service_name = ?, description = ?, price = ?, status = ?
                    WHERE service_id = ?
                ');
                $stmt->execute([$service_name, $description, $price, $status, $service_id]);
                setFlashNotice('success', 'Service "' . $service_name . '" updated successfully.');
            } else {
                // Insert
                $stmt = $pdo->prepare('
                    INSERT INTO services (service_name, description, price, status, created_by)
                    VALUES (?, ?, ?, ?, ?)
                ');
                $stmt->execute([$service_name, $description, $price, $status, $_SESSION['user_id']]);
                setFlashNotice('success', 'Service "' . $service_name . '" created successfully.');
            }
            header('Location: admin_services.php');
            exit;
        } catch (PDOException $e) {
            $error = 'Failed to save service: ' . $e->getMessage();
        }
    }
}

// Fetch Active Service details if editing
$edit_service = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    try {
        $stmt = $pdo->prepare('SELECT * FROM services WHERE service_id = ? LIMIT 1');
        $stmt->execute([$edit_id]);
        $edit_service = $stmt->fetch();
    } catch (PDOException $e) {
        $error = 'Failed to load service for editing: ' . $e->getMessage();
    }
}

// Fetch all services
$services = [];
try {
    $stmt = $pdo->query('SELECT * FROM services ORDER BY service_id DESC');
    $services = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to load catalog: ' . $e->getMessage();
}

$pageTitle = "Configure Services";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <div class="dashboard-title">
        <h1>Services Catalog Management</h1>
        <p>Configure solutions, control pricing, and update visibility status settings.</p>
    </div>
    <div>
        <a href="admin_dashboard.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            Back to Admin Panel
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<div class="home-grid">
    <!-- List Services Card -->
    <div class="glass-container">
        <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">Available Services</h2>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Service Details</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($services)): ?>
                        <tr>
                            <td colspan="4" style="text-align: center; color: var(--text-muted); padding: 1.5rem 0;">No services added yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($services as $service): ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($service['service_name']); ?></strong>
                                    <p style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 0.25rem;">
                                        <?php echo e($service['description'] ?: 'No description provided.'); ?>
                                    </p>
                                </td>
                                <td><?php echo $service['price'] !== null ? '$' . number_format($service['price'], 2) : '<em>Quote</em>'; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo e($service['status']); ?>">
                                        <?php echo e($service['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a href="admin_services.php?edit_id=<?php echo $service['service_id']; ?>" class="btn btn-secondary btn-sm" style="text-decoration: none;">Edit</a>
                                        <form method="POST" action="admin_services.php" onsubmit="return confirm('Are you sure you want to delete this service?');" style="margin: 0;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="service_id" value="<?php echo $service['service_id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add/Edit Form Card -->
    <div class="glass-container">
        <h2 id="form-title" style="font-size: 1.5rem; margin-bottom: 1.5rem;">
            <?php echo $edit_service ? 'Edit Service' : 'Add New Service'; ?>
        </h2>
        <form method="POST" action="admin_services.php" autocomplete="off">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="service_id" value="<?php echo $edit_service ? $edit_service['service_id'] : '0'; ?>">
            
            <div class="form-group">
                <label for="service_name">Service Name *</label>
                <input type="text" name="service_name" id="service_name" class="form-control" placeholder="e.g. System Integration" value="<?php echo $edit_service ? e($edit_service['service_name']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" id="description" class="form-control" placeholder="Detailed service description..."><?php echo $edit_service ? e($edit_service['description']) : ''; ?></textarea>
            </div>

            <div class="form-group">
                <label for="price">Price (Leave blank for custom quote)</label>
                <input type="number" name="price" id="price" step="0.01" min="0" class="form-control" placeholder="e.g. 499.99" value="<?php echo $edit_service && $edit_service['price'] !== null ? $edit_service['price'] : ''; ?>">
            </div>

            <div class="form-group">
                <label for="status">Status</label>
                <select name="status" id="status" class="form-control">
                    <option value="active" <?php echo $edit_service && $edit_service['status'] === 'active' ? 'selected' : ''; ?>>Active (Visible to customer)</option>
                    <option value="inactive" <?php echo $edit_service && $edit_service['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive (Hidden)</option>
                </select>
            </div>

            <div class="d-flex gap-2" style="margin-top: 1.5rem;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">
                    <?php echo $edit_service ? 'Update Service' : 'Create Service'; ?>
                </button>
                <?php if ($edit_service): ?>
                    <a href="admin_services.php" class="btn btn-secondary" style="flex: 1; text-align: center; text-decoration: none; line-height: 2.2;">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php
require_once 'footer.php';
?>
