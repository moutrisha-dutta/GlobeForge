<?php
// GlobeForge Customer Portal Dashboard
// File: customer_dashboard.php

require_once 'config.php';
authorize(['customer']);

$customer_id = $_SESSION['user_id'];
$error = null;

// Handle request service POST submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'request_service') {
    $service_id = intval($_POST['service_id'] ?? 0);
    
    try {
        // Validate service
        $stmt = $pdo->prepare('SELECT service_id, service_name, status FROM services WHERE service_id = ? LIMIT 1');
        $stmt->execute([$service_id]);
        $service = $stmt->fetch();
        
        if ($service && $service['status'] === 'active') {
            // Check if already requested and pending/confirmed (optional, but let's allow duplicates as per instructions unless restricted)
            $stmt = $pdo->prepare('
                INSERT INTO service_requests (customer_id, service_id, status)
                VALUES (?, ?, \'pending\')
            ');
            $stmt->execute([$customer_id, $service_id]);
            
            setFlashNotice('success', 'Requested "' . $service['service_name'] . '" successfully. Contact admin for approval.');
            header('Location: customer_dashboard.php');
            exit;
        } else {
            $error = 'Selected service is invalid or inactive.';
        }
    } catch (PDOException $e) {
        $error = 'Failed to submit request: ' . $e->getMessage();
    }
}

// Fetch Customer's Service Requests
$requests = [];
try {
    $stmt = $pdo->prepare('
        SELECT sr.*, s.service_name, s.price 
        FROM service_requests sr
        JOIN services s ON sr.service_id = s.service_id
        WHERE sr.customer_id = ?
        ORDER BY sr.requested_at DESC
    ');
    $stmt->execute([$customer_id]);
    $requests = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to load requests: ' . $e->getMessage();
}

// Fetch Available Services for the Choose a Service catalog
$catalog = [];
try {
    $stmt = $pdo->prepare('SELECT * FROM services WHERE status = "active" ORDER BY service_name ASC');
    $stmt->execute();
    $catalog = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to load service catalog: ' . $e->getMessage();
}

$pageTitle = "Customer Dashboard";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <div class="dashboard-title">
        <h1>Welcome back, <span><?php echo e($_SESSION['full_name']); ?></span></h1>
        <p>Manage your account, request new solutions, and track project reviews.</p>
    </div>
    <div>
        <a href="customer_profile.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
            Edit Profile
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<!-- Requested Services Table -->
<div class="glass-container" style="margin-bottom: 2rem;">
    <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">My Service Requests</h2>
    <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">Below is the live status of services you have requested. Please contact administration for approval details.</p>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Service Name</th>
                    <th>Price</th>
                    <th>Requested Date</th>
                    <th>Status</th>
                    <th>Admin Remarks</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($requests)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 2rem 0;">
                            You haven't requested any services yet. Choose a service from the catalog below!
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><strong><?php echo e($req['service_name']); ?></strong></td>
                            <td><?php echo $req['price'] !== null ? '$' . number_format($req['price'], 2) : 'Quote Needed'; ?></td>
                            <td><?php echo e($req['requested_at']); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e($req['status']); ?>">
                                    <?php echo e($req['status']); ?>
                                </span>
                            </td>
                            <td style="color: var(--text-secondary);">
                                <?php echo $req['admin_remarks'] ? e($req['admin_remarks']) : '<em>No remarks yet</em>'; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Catalog Section -->
<div class="glass-container">
    <h2 style="font-size: 1.5rem; margin-bottom: 1.5rem;">Choose a Service</h2>
    <div class="services-grid">
        <?php if (empty($catalog)): ?>
            <p style="color: var(--text-muted);">No services are currently configured in the database.</p>
        <?php else: ?>
            <?php foreach ($catalog as $service): ?>
                <div class="service-card">
                    <div>
                        <h3><?php echo e($service['service_name']); ?></h3>
                        <p><?php echo e($service['description'] ?: 'No description provided.'); ?></p>
                    </div>
                    <div class="service-card-footer">
                        <span class="service-price">
                            <?php echo $service['price'] !== null ? '$' . number_format($service['price'], 2) : 'Quote'; ?>
                        </span>
                        
                        <form method="POST" action="customer_dashboard.php">
                            <input type="hidden" name="service_id" value="<?php echo $service['service_id']; ?>">
                            <input type="hidden" name="action" value="request_service">
                            <button type="submit" class="btn btn-primary btn-sm">Request Service</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php
require_once 'footer.php';
?>
