<?php
// GlobeForge Request Approvals Moderation
// File: admin_requests.php

require_once 'config.php';
authorize(['admin']);

$error = null;
$success = null;

// Handle Moderation Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'moderate') {
    $request_id = intval($_POST['request_id'] ?? 0);
    $status = $_POST['status'] ?? 'pending';
    $remarks = trim($_POST['admin_remarks'] ?? '');
    $approved_by = $_SESSION['user_id'];
    
    if ($request_id > 0) {
        if (!in_array($status, ['pending', 'confirmed', 'successful', 'contact_us'])) {
            $error = 'Invalid status value selected.';
        } else {
            try {
                $stmt = $pdo->prepare('
                    UPDATE service_requests 
                    SET status = ?, admin_remarks = ?, approved_by = ?
                    WHERE request_id = ?
                ');
                $stmt->execute([$status, $remarks === '' ? null : $remarks, $approved_by, $request_id]);
                setFlashNotice('success', 'Service request moderated successfully.');
                header('Location: admin_requests.php');
                exit;
            } catch (PDOException $e) {
                $error = 'Failed to moderate request: ' . $e->getMessage();
            }
        }
    } else {
        $error = 'Invalid Request ID.';
    }
}

// Fetch Active Moderating request if editing
$edit_request = null;
if (isset($_GET['edit_id'])) {
    $edit_id = intval($_GET['edit_id']);
    try {
        $stmt = $pdo->prepare('
            SELECT sr.*, u.full_name as customer_name, s.service_name 
            FROM service_requests sr
            JOIN users u ON sr.customer_id = u.user_id
            JOIN services s ON sr.service_id = s.service_id
            WHERE sr.request_id = ? LIMIT 1
        ');
        $stmt->execute([$edit_id]);
        $edit_request = $stmt->fetch();
    } catch (PDOException $e) {
        $error = 'Failed to load request details: ' . $e->getMessage();
    }
}

// Fetch all requests
$requests = [];
try {
    $stmt = $pdo->query('
        SELECT sr.*, u.full_name as customer_name, u.email as customer_email, s.service_name, s.price, admin_user.full_name as approved_by_name
        FROM service_requests sr
        JOIN users u ON sr.customer_id = u.user_id
        JOIN services s ON sr.service_id = s.service_id
        LEFT JOIN users admin_user ON sr.approved_by = admin_user.user_id
        ORDER BY sr.requested_at DESC
    ');
    $requests = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to load request logs: ' . $e->getMessage();
}

$pageTitle = "Moderate Approvals";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <div class="dashboard-title">
        <h1>Service Requests Approval Panel</h1>
        <p>Review customer service inquiries, update deployment states, and leave guidance comments.</p>
    </div>
    <div>
        <a href="admin_dashboard.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            Back to Admin Panel
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<div class="home-grid" style="grid-template-columns: <?php echo $edit_request ? '1.2fr 0.8fr' : '1fr'; ?>;">
    <!-- Requests List Container -->
    <div class="glass-container">
        <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">Service Request Log</h2>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Service Requested</th>
                        <th>Price</th>
                        <th>Requested At</th>
                        <th>Status</th>
                        <th>Admin Remarks</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($requests)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 1.5rem 0;">No service requests logged yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($requests as $req): ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($req['customer_name']); ?></strong>
                                    <div style="font-size: 0.8rem; color: var(--text-secondary);"><?php echo e($req['customer_email']); ?></div>
                                </td>
                                <td><?php echo e($req['service_name']); ?></td>
                                <td><?php echo $req['price'] !== null ? '$' . number_format($req['price'], 2) : '<em>Quote</em>'; ?></td>
                                <td><span style="font-size: 0.85rem; color: var(--text-secondary);"><?php echo e($req['requested_at']); ?></span></td>
                                <td>
                                    <span class="badge badge-<?php echo e($req['status']); ?>">
                                        <?php echo e($req['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div style="font-size: 0.85rem; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        <?php if ($req['admin_remarks']): ?>
                                            <?php echo e($req['admin_remarks']); ?>
                                            <div style="font-size: 0.75rem; color: var(--text-muted);">By: <?php echo e($req['approved_by_name']); ?></div>
                                        <?php else: ?>
                                            <span style="color: var(--text-muted); font-style: italic;">No remarks</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <a href="admin_requests.php?edit_id=<?php echo $req['request_id']; ?>" class="btn btn-primary btn-sm" style="text-decoration: none;">Review</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Moderation/Edit Panel -->
    <?php if ($edit_request): ?>
        <div class="glass-container">
            <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">Review Request</h2>
            
            <div style="margin-bottom: 1.5rem; font-size: 0.95rem;">
                <div class="mb-2"><strong>Customer:</strong> <span><?php echo e($edit_request['customer_name']); ?></span></div>
                <div class="mb-2"><strong>Service:</strong> <span><?php echo e($edit_request['service_name']); ?></span></div>
            </div>

            <hr class="section-divider" style="margin: 1.5rem 0; border: 0; border-top: 1px solid rgba(255, 255, 255, 0.1);">

            <form method="POST" action="admin_requests.php" autocomplete="off">
                <input type="hidden" name="action" value="moderate">
                <input type="hidden" name="request_id" value="<?php echo $edit_request['request_id']; ?>">
                
                <div class="form-group">
                    <label for="status">Change Request Status</label>
                    <select name="status" id="status" class="form-control">
                        <option value="pending" <?php echo $edit_request['status'] === 'pending' ? 'selected' : ''; ?>>Pending Review</option>
                        <option value="confirmed" <?php echo $edit_request['status'] === 'confirmed' ? 'selected' : ''; ?>>Confirmed (Work In Progress)</option>
                        <option value="successful" <?php echo $edit_request['status'] === 'successful' ? 'selected' : ''; ?>>Successful (Completed)</option>
                        <option value="contact_us" <?php echo $edit_request['status'] === 'contact_us' ? 'selected' : ''; ?>>Contact Us (Action Required)</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="admin_remarks">Admin Remarks / Feedback</label>
                    <textarea name="admin_remarks" id="admin_remarks" class="form-control" placeholder="Add details or custom message for customer..."><?php echo e($edit_request['admin_remarks']); ?></textarea>
                </div>

                <div class="d-flex gap-2" style="margin-top: 1.5rem;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">Save Moderation</button>
                    <a href="admin_requests.php" class="btn btn-secondary" style="flex: 1; text-align: center; text-decoration: none; line-height: 2.2;">Cancel</a>
                </div>
            </form>
        </div>
    <?php endif; ?>
</div>

<?php
require_once 'footer.php';
?>
