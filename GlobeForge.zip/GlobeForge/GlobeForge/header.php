<?php
// GlobeForge Dynamic Header
// File: header.php

require_once 'config.php';

$currentPage = basename($_SERVER['SCRIPT_NAME']);
$activeClass = function($page) use ($currentPage) {
    return $currentPage === $page ? 'active' : '';
};

// Check if user is logged in
$user = null;
if (isset($_SESSION['user_id'])) {
    $user = [
        'user_id' => $_SESSION['user_id'],
        'role' => $_SESSION['role'],
        'email' => $_SESSION['email'],
        'full_name' => $_SESSION['full_name']
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . " - GlobeForge" : "GlobeForge - Enterprise Solutions"; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="app-container">
        <?php 
        $isAdminSection = (strpos($currentPage, 'admin_') === 0);
        if (!$isAdminSection): 
        ?>
        <header>
            <nav class="navbar">
                <div class="logo-container">
                    <a href="index.php">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 0.25rem;"><circle cx="12" cy="12" r="10"></circle><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path><path d="M2 12h20"></path></svg>
                        GlobeForge
                    </a>
                </div>
                <ul class="nav-links">
                    <li><a href="index.php" class="<?php echo $activeClass('index.php'); ?>">Home</a></li>
                    <li><a href="about.php" class="<?php echo $activeClass('about.php'); ?>">About Us</a></li>
                    <li><a href="contact.php" class="<?php echo $activeClass('contact.php'); ?>">Contact Us</a></li>
                    
                    <?php if ($user): ?>
                        <?php if ($user['role'] === 'admin'): ?>
                            <li><a href="admin_dashboard.php" class="<?php echo $activeClass('admin_dashboard.php'); ?>">Dashboard</a></li>
                            <li><a href="admin_services.php" class="<?php echo $activeClass('admin_services.php'); ?>">Services</a></li>
                            <li><a href="admin_employees.php" class="<?php echo $activeClass('admin_employees.php'); ?>">Employees</a></li>
                            <li><a href="admin_requests.php" class="<?php echo $activeClass('admin_requests.php'); ?>">Approvals</a></li>
                            <li><a href="admin_inquiries.php" class="<?php echo $activeClass('admin_inquiries.php'); ?>">Inquiries</a></li>
                            <li><a href="admin_profile.php" class="<?php echo $activeClass('admin_profile.php'); ?>">Profile</a></li>
                        <?php else: ?>
                            <li><a href="customer_dashboard.php" class="<?php echo $activeClass('customer_dashboard.php'); ?>">My Services</a></li>
                            <li><a href="customer_profile.php" class="<?php echo $activeClass('customer_profile.php'); ?>">My Profile</a></li>
                        <?php endif; ?>
                        
                        <li class="user-tag">
                            <span class="role-badge"><?php echo e($user['role']); ?></span>
                            <?php echo e($user['full_name']); ?>
                        </li>
                        <li>
                            <a href="logout.php" class="btn btn-secondary btn-sm" style="padding: 0.35rem 0.75rem; text-decoration: none;">Logout</a>
                        </li>
                    <?php else: ?>
                        <li><a href="login.php" class="btn btn-secondary btn-sm" style="padding: 0.35rem 0.75rem; text-decoration: none;">Login</a></li>
                        <li><a href="register.php" class="btn btn-primary btn-sm" style="padding: 0.35rem 0.75rem; color: #ffffff; text-decoration: none;">Register</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        <?php endif; ?>
        
        <?php 
        if ($isAdminSection && isset($_SESSION['admin_login_time'])): 
            $remainingSeconds = max(0, 7200 - (time() - $_SESSION['admin_login_time']));
        ?>
        <style>
        .admin-session-timer {
            position: fixed;
            top: 1rem;
            right: 1rem;
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.15);
            padding: 0.5rem 0.85rem;
            border-radius: 30px;
            font-size: 0.85rem;
            color: #ffffff;
            display: flex;
            align-items: center;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3);
            z-index: 9999;
            transition: background-color 0.5s ease, border-color 0.5s ease;
        }
        .admin-session-timer svg {
            color: #a855f7;
            margin-right: 0.35rem;
        }
        </style>
        <div class="admin-session-timer" id="session-timer-widget">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            <span>Session Remaining: <strong id="session-countdown">--:--:--</strong></span>
        </div>
        <script>
        document.addEventListener('DOMContentLoaded', () => {
            let remainingSeconds = <?php echo (int)$remainingSeconds; ?>;
            const countdownEl = document.getElementById('session-countdown');
            const widgetEl = document.getElementById('session-timer-widget');
            
            function updateTimer() {
                if (remainingSeconds <= 0) {
                    countdownEl.textContent = "Expired";
                    window.location.href = 'logout.php';
                    return;
                }
                
                const hours = Math.floor(remainingSeconds / 3600);
                const minutes = Math.floor((remainingSeconds % 3600) / 60);
                const seconds = remainingSeconds % 60;
                
                const formatted = 
                    String(hours).padStart(2, '0') + ':' + 
                    String(minutes).padStart(2, '0') + ':' + 
                    String(seconds).padStart(2, '0');
                    
                countdownEl.textContent = formatted;
                
                if (remainingSeconds < 300) { // Less than 5 minutes
                    widgetEl.style.backgroundColor = 'rgba(239, 68, 68, 0.25)';
                    widgetEl.style.borderColor = 'rgba(239, 68, 68, 0.4)';
                    countdownEl.style.color = '#ef4444';
                }
                
                remainingSeconds--;
            }
            
            updateTimer();
            setInterval(updateTimer, 1000);
        });
        </script>
        <?php endif; ?>
        <main>
            <div id="notice-container">
                <?php echo displayFlashNotice(); ?>
            </div>
