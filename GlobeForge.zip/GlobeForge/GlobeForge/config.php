<?php
// GlobeForge Configuration Loader & Database Connection
// File: config.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Automatic Admin Session Expiration (2 hours)
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    if (isset($_SESSION['admin_login_time'])) {
        $elapsed = time() - $_SESSION['admin_login_time'];
        if ($elapsed > 7200) { // 2 hours = 7200 seconds
            $_SESSION = [];
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            session_destroy();
            session_start();
            setFlashNotice('danger', 'Your administrator session has expired (2-hour limit). Please log in again.');
            header('Location: login.php');
            exit;
        }
    }
}

// Function to parse .env file
function loadEnv($filePath) {
    if (!file_exists($filePath)) {
        return;
    }
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        // Ignore comments
        if (strpos($line, '#') === 0 || empty($line)) {
            continue;
        }
        if (strpos($line, '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            
            // Remove surrounding quotes if any
            if (preg_match('/^"(.*)"$/', $value, $matches)) {
                $value = $matches[1];
            } elseif (preg_match('/^\'(.*)\'$/', $value, $matches)) {
                $value = $matches[1];
            }
            
            if (!array_key_exists($name, $_SERVER) && !array_key_exists($name, $_ENV)) {
                putenv(sprintf('%s=%s', $name, $value));
                $_ENV[$name] = $value;
                $_SERVER[$name] = $value;
            }
        }
    }
}

// Load root level environment variables
loadEnv(__DIR__ . '/.env');

$db_host = getenv('DB_HOST') ?: '127.0.0.1';
$db_name = getenv('DB_NAME') ?: 'admin_db';
$db_user = getenv('DB_USER') ?: 'root';
$db_pass = getenv('DB_PASS') !== false ? getenv('DB_PASS') : '';

$dsn = "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (\PDOException $e) {
    die("Database connection failed: " . htmlspecialchars($e->getMessage()));
}

// Helper to check user authentication and role authorization
function authorize($allowedRoles = []) {
    if (!isset($_SESSION['user_id'])) {
        setFlashNotice('danger', 'You must log in to access this page.');
        header('Location: login.php');
        exit;
    }
    if (!empty($allowedRoles) && !in_array($_SESSION['role'], $allowedRoles)) {
        setFlashNotice('danger', 'Unauthorized access.');
        header('Location: index.php');
        exit;
    }
}

// Helper to escape HTML values safely
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

// Flash Notice system
function setFlashNotice($type, $message) {
    $_SESSION['flash_notice'] = [
        'type' => $type, // 'success' or 'danger'
        'message' => $message
    ];
}

function displayFlashNotice() {
    if (isset($_SESSION['flash_notice'])) {
        $notice = $_SESSION['flash_notice'];
        unset($_SESSION['flash_notice']);
        
        $class = $notice['type'] === 'success' ? 'alert-success' : 'alert-danger';
        $icon = $notice['type'] === 'success' 
            ? '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>'
            : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>';
        
        return "
            <div class=\"alert {$class}\">
                {$icon}
                <span>" . e($notice['message']) . "</span>
            </div>
        ";
    }
    return '';
}
?>
