<?php
// GlobeForge Customer Profile Management
// File: customer_profile.php

require_once 'config.php';
authorize(['customer']);

$customer_id = $_SESSION['user_id'];
$error = null;

// Fetch current user details
try {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ? LIMIT 1');
    $stmt->execute([$customer_id]);
    $user = $stmt->fetch();
    if (!$user) {
        setFlashNotice('danger', 'User account not found.');
        header('Location: logout.php');
        exit;
    }
} catch (PDOException $e) {
    $error = 'Failed to load user profile: ' . $e->getMessage();
}

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete_profile') {
        // Delete Profile
        try {
            $stmt = $pdo->prepare('DELETE FROM users WHERE user_id = ?');
            $stmt->execute([$customer_id]);
            
            $_SESSION = [];
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $params["path"], $params["domain"],
                    $params["secure"], $params["httponly"]
                );
            }
            session_destroy();
            
            session_start();
            setFlashNotice('success', 'Your profile and request logs have been permanently deleted.');
            header('Location: index.php');
            exit;
        } catch (PDOException $e) {
            $error = 'Failed to delete profile: ' . $e->getMessage();
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        // Update Profile
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $mobile = trim($_POST['mobile_number'] ?? '');
        $password = $_POST['password'] ?? '';
        
        if (empty($full_name) || empty($email) || empty($mobile)) {
            $error = 'Full Name, Email, and Mobile Number are required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } else {
            try {
                // Check duplicate details in other accounts
                $stmt = $pdo->prepare('SELECT user_id, email, mobile_number FROM users WHERE (email = ? OR mobile_number = ?) AND user_id != ? LIMIT 1');
                $stmt->execute([$email, $mobile, $customer_id]);
                $existing = $stmt->fetch();
                
                if ($existing) {
                    if ($existing['email'] === $email) {
                        $error = 'Email is already registered by another account.';
                    } else {
                        $error = 'Mobile number is already registered by another account.';
                    }
                } else {
                    if (!empty($password)) {
                        if (strlen($password) < 6) {
                            $error = 'Password must be at least 6 characters.';
                        } else {
                            $pwd_hash = password_hash($password, PASSWORD_BCRYPT);
                            $stmt = $pdo->prepare('UPDATE users SET full_name = ?, email = ?, mobile_number = ?, password_hash = ? WHERE user_id = ?');
                            $stmt->execute([$full_name, $email, $mobile, $pwd_hash, $customer_id]);
                        }
                    } else {
                        $stmt = $pdo->prepare('UPDATE users SET full_name = ?, email = ?, mobile_number = ? WHERE user_id = ?');
                        $stmt->execute([$full_name, $email, $mobile, $customer_id]);
                    }
                    
                    if (!$error) {
                        $_SESSION['full_name'] = $full_name;
                        $_SESSION['email'] = $email;
                        setFlashNotice('success', 'Profile updated successfully.');
                        header('Location: customer_profile.php');
                        exit;
                    }
                }
            } catch (PDOException $e) {
                $error = 'Profile update failed: ' . $e->getMessage();
            }
        }
    }
}

$pageTitle = "My Profile";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <div class="dashboard-title">
        <h1>Profile Management</h1>
        <p>Modify your user profile details or manage account deletion rules.</p>
    </div>
    <div>
        <a href="customer_dashboard.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            Back to Dashboard
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<div class="home-grid">
    <!-- Edit Form Card -->
    <div class="glass-container">
        <h2 style="font-size: 1.5rem; margin-bottom: 1.5rem;">Update Account Details</h2>
        <form method="POST" action="customer_profile.php" autocomplete="off">
            <input type="hidden" name="action" value="update_profile">
            
            <div class="form-group">
                <label for="full_name">Full Name *</label>
                <input type="text" name="full_name" id="full_name" class="form-control" value="<?php echo e($user['full_name']); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user['email']); ?>" required>
            </div>

            <div class="form-group">
                <label for="mobile_number">Mobile Number *</label>
                <input type="text" name="mobile_number" id="mobile_number" class="form-control" value="<?php echo e($user['mobile_number']); ?>" placeholder="e.g. 9999999999" required>
            </div>

            <div class="form-group">
                <label for="password">New Password (Leave blank to keep current)</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter new password">
            </div>

            <button type="submit" class="btn btn-primary" style="margin-top: 1rem; width: 100%;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                Save Profile
            </button>
        </form>
    </div>

    <!-- Account Deletion Card -->
    <div class="glass-container d-flex flex-column justify-between" style="justify-content: space-between;">
        <div>
            <h2 style="font-size: 1.5rem; color: var(--danger); margin-bottom: 1rem;">Danger Zone</h2>
            <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">
                Deleting your profile is a permanent action. All your profile info, registered configuration details, and pending/confirmed service requests will be permanently erased.
            </p>
            <div class="alert alert-danger" style="background: rgba(239, 68, 68, 0.05); border-color: rgba(239, 68, 68, 0.1); margin-bottom: 1.5rem;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
                <span>Warning: This cannot be undone!</span>
            </div>
        </div>

        <form method="POST" action="customer_profile.php" onsubmit="return confirm('Are you absolutely sure you want to delete your profile permanently? This action cannot be undone and all your requested service data will be erased.');">
            <input type="hidden" name="action" value="delete_profile">
            <button type="submit" class="btn btn-danger" style="width: 100%;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                Delete Profile permanently
            </button>
        </form>
    </div>
</div>

<?php
require_once 'footer.php';
?>
