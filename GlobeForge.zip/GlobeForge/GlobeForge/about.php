<?php
// GlobeForge About Page
// File: about.php

$pageTitle = "About Us";
require_once 'config.php';
require_once 'header.php';
?>

<!-- Hero Header -->
<div class="hero" style="padding: 2rem 1rem;">
    <h1>About GlobeForge</h1>
    <p>Learn more about our mission, technology stack, and dedication to enterprise solutions.</p>
</div>

<!-- About Content Section -->
<div class="glass-container">
    <h2 style="font-size: 2rem; margin-bottom: 1.5rem; text-align: center; background: linear-gradient(to right, #ffffff, #a855f7); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Who We Are</h2>
    <p style="color: var(--text-secondary); margin-bottom: 1.5rem; font-size: 1.05rem; text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;">
        GlobeForge is a state-of-the-art enterprise resource management and workflow platform. We specialize in providing highly secure, unified login systems, employee directory validation tools, and customizable service request pipelines designed to help businesses scale efficiently.
    </p>
    <p style="color: var(--text-secondary); font-size: 1.05rem; text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;">
        Our architecture runs on secure server-rendered PHP pages, leveraging standard environment file configs and PDO safety checks to deliver lightning-fast, premium experiences.
    </p>
</div>

<!-- Meet Our Leadership Section -->
<div class="glass-container" style="margin-top: 2rem;">
    <h2 style="font-size: 2rem; margin-bottom: 1rem; text-align: center; background: linear-gradient(to right, #ffffff, #a855f7); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Meet Our Leadership</h2>
    <p style="color: var(--text-secondary); text-align: center; margin-bottom: 2rem; max-width: 600px; margin-left: auto; margin-right: auto; font-size: 0.95rem;">
        The strategic minds driving security-first innovations, workflow efficiency, and seamless product execution.
    </p>

    <div class="team-grid">
        <!-- Founder Card -->
        <div class="team-card">
            <div class="team-avatar-container">
                <img src="images/avatar_founder.png" alt="Dr. Vikram Sen - Founder">
            </div>
            <h3>Dr. Vikram Sen</h3>
            <span class="team-role">Founder</span>
            <p class="team-description">
                A visionary security researcher with 15+ years of experience in system architecture and cryptography. Vikram directs the long-term technical expansion of GlobeForge.
            </p>
        </div>

        <!-- Co-Founder Card -->
        <div class="team-card">
            <div class="team-avatar-container">
                <img src="images/avatar_cofounder.png" alt="Elena Rostova - Co-Founder">
            </div>
            <h3>Elena Rostova</h3>
            <span class="team-role">Co-Founder</span>
            <p class="team-description">
                Passionate about workflow management and interface logic. Elena coordinates product features and ensures high accessibility and product-market fit.
            </p>
        </div>

        <!-- Director Card -->
        <div class="team-card">
            <div class="team-avatar-container">
                <img src="images/avatar_director.png" alt="Sarah Jenkins - Director">
            </div>
            <h3>Sarah Jenkins</h3>
            <span class="team-role">Director</span>
            <p class="team-description">
                Sarah steers GlobeForge's global operations, client onboarding pipelines, and executive compliance checks. She focuses on corporate growth.
            </p>
        </div>

        <!-- Manager Card -->
        <div class="team-card">
            <div class="team-avatar-container">
                <img src="images/avatar_manager.png" alt="Marcus Vance - Manager">
            </div>
            <h3>Marcus Vance</h3>
            <span class="team-role">Manager</span>
            <p class="team-description">
                Marcus oversees regional operations, technical support lines, and employee system training. He keeps the workspace scaling reliably.
            </p>
        </div>
    </div>
</div>

<!-- Vision and Pillars -->
<div class="home-grid">
    <div class="glass-container">
        <h3 style="font-size: 1.5rem; margin-bottom: 1rem; color: #ffffff; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            Security-First
        </h3>
        <p style="color: var(--text-secondary);">
            We utilize password hashing (`PASSWORD_BCRYPT`) and parameterized PDO statements to block malicious interactions. Configuration settings are locked safely inside environment-scoped variables.
        </p>
    </div>
    <div class="glass-container">
        <h3 style="font-size: 1.5rem; margin-bottom: 1rem; color: #ffffff; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 7 12 12 22 7 12 2z"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>
            Server-Rendered Performance
        </h3>
        <p style="color: var(--text-secondary);">
            By serving templates and processing data streams directly on the server, we optimize first-paint load times and eliminate browser-side API fetching delays completely.
        </p>
    </div>
</div>

<?php
require_once 'footer.php';
?>
