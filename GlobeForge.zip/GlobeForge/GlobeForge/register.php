<?php
// GlobeForge Customer Registration
// File: register.php

$pageTitle = "Register";
require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile_number'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($full_name) || empty($email) || empty($mobile) || empty($password)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        try {
            // Check duplicates
            $stmt = $pdo->prepare('SELECT email, mobile_number FROM users WHERE email = ? OR mobile_number = ? LIMIT 1');
            $stmt->execute([$email, $mobile]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                if ($existing['email'] === $email) {
                    $error = 'Email is already registered.';
                } else {
                    $error = 'Mobile number is already registered.';
                }
            } else {
                $password_hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare('
                    INSERT INTO users (role, email, mobile_number, full_name, password_hash, status)
                    VALUES (\'customer\', ?, ?, ?, ?, \'active\')
                ');
                $stmt->execute([$email, $mobile, $full_name, $password_hash]);
                
                setFlashNotice('success', 'Registration successful! You can now log in.');
                header('Location: login.php');
                exit;
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

require_once 'header.php';
?>

<div class="auth-wrapper">
    <div class="glass-container" style="max-width: 480px; margin: 2rem auto;">
        <div class="auth-title" style="text-align: center; margin-bottom: 1.5rem;">
            <h2>Register Account</h2>
            <p class="mt-1" style="color: var(--text-secondary);">Create a customer portal account</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger mb-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                <span><?php echo e($error); ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="register.php" autocomplete="off">
            <div class="form-group">
                <label for="full_name">Full Name *</label>
                <input type="text" name="full_name" id="full_name" class="form-control" placeholder="e.g. Alice Smith" value="<?php echo isset($full_name) ? e($full_name) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="name@example.com" value="<?php echo isset($email) ? e($email) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="mobile_number">Mobile Number *</label>
                <input type="tel" name="mobile_number" id="mobile_number" class="form-control" placeholder="e.g. 9876543210" value="<?php echo isset($mobile) ? e($mobile) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password *</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="At least 6 characters" required>
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 0.25rem;"><path d="M16 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle><line x1="20" y1="8" x2="20" y2="14"></line><line x1="23" y1="11" x2="17" y2="11"></line></svg>
                Register
            </button>
        </form>

        <div class="auth-footer" style="text-align: center; margin-top: 1.5rem; color: var(--text-secondary); font-size: 0.9rem;">
            Already have an account? <a href="login.php" style="color: var(--primary);">Sign in here</a>
        </div>
    </div>
</div>

<?php
require_once 'footer.php';
?>
