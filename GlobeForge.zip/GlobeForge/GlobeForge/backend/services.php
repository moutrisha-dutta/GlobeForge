<?php
// GlobeForge Services & Request Controller API
// File: backend/services.php

require_once 'config.php';

$action = $_GET['action'] ?? '';

// 1. GET Listing of Services (accessible to anyone, filtering by status for guest/customer)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'list') {
    $is_admin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    try {
        if ($is_admin) {
            $stmt = $pdo->query('SELECT * FROM services ORDER BY service_id DESC');
        } else {
            $stmt = $pdo->query('SELECT * FROM services WHERE status = \'active\' ORDER BY service_name ASC');
        }
        $services = $stmt->fetchAll();
        sendResponse(true, $services, 'Services catalog loaded.');
    } catch (PDOException $e) {
        sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
    }
}

// -------------------------------------------------------------
// Authentication required for remaining actions
// -------------------------------------------------------------
if (!isset($_SESSION['user_id'])) {
    sendResponse(false, [], 'Unauthorized. Please login.', 401);
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'requests') {
        try {
            if ($role === 'admin') {
                // Fetch all customer service requests
                $stmt = $pdo->query('
                    SELECT sr.*, u.full_name as customer_name, u.email as customer_email, s.service_name, s.price, admin_user.full_name as approved_by_name
                    FROM service_requests sr
                    JOIN users u ON sr.customer_id = u.user_id
                    JOIN services s ON sr.service_id = s.service_id
                    LEFT JOIN users admin_user ON sr.approved_by = admin_user.user_id
                    ORDER BY sr.requested_at DESC
                ');
            } else {
                // Fetch customer's own service requests
                $stmt = $pdo->prepare('
                    SELECT sr.request_id, sr.status, sr.admin_remarks, sr.requested_at, s.service_name, s.price
                    FROM service_requests sr
                    JOIN services s ON sr.service_id = s.service_id
                    WHERE sr.customer_id = ?
                    ORDER BY sr.requested_at DESC
                ');
                $stmt->execute([$user_id]);
            }
            $requests = $stmt->fetchAll();
            sendResponse(true, $requests, 'Service requests log retrieved.');
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }
    } else {
        sendResponse(false, [], 'Action not found.', 400);
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    // Customer: Request a service
    if ($action === 'request_service') {
        if ($role !== 'customer') {
            sendResponse(false, [], 'Only customers can request services.', 403);
        }

        $service_id = intval($input['service_id'] ?? 0);
        if (empty($service_id)) {
            sendResponse(false, [], 'Service ID is required.', 400);
        }

        try {
            // Verify if service exists and is active
            $check = $pdo->prepare('SELECT service_id, service_name FROM services WHERE service_id = ? AND status = \'active\'');
            $check->execute([$service_id]);
            $service = $check->fetch();

            if (!$service) {
                sendResponse(false, [], 'Invalid or inactive service.', 400);
            }

            $stmt = $pdo->prepare('
                INSERT INTO service_requests (customer_id, service_id, status, admin_remarks, approved_by, requested_at)
                VALUES (?, ?, \'pending\', NULL, NULL, CURRENT_TIMESTAMP)
            ');
            $stmt->execute([$user_id, $service_id]);

            sendResponse(true, [], 'Service requested successfully. Admin review is pending.');
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }

    // Admin: Save/Create/Update service
    } elseif ($action === 'save') {
        if ($role !== 'admin') {
            sendResponse(false, [], 'Admin authorization required.', 403);
        }

        $service_id = intval($input['service_id'] ?? 0);
        $service_name = trim($input['service_name'] ?? '');
        $description = trim($input['description'] ?? '');
        $price = $input['price'] !== '' && $input['price'] !== null ? floatval($input['price']) : null;
        $status = $input['status'] ?? 'active';
        $is_edit = filter_var($input['is_edit'] ?? false, FILTER_VALIDATE_BOOLEAN);

        if (empty($service_name)) {
            sendResponse(false, [], 'Service Name is required.', 400);
        }

        try {
            if ($is_edit && $service_id) {
                $stmt = $pdo->prepare('
                    UPDATE services 
                    SET service_name = ?, description = ?, price = ?, status = ?
                    WHERE service_id = ?
                ');
                $stmt->execute([$service_name, $description, $price, $status, $service_id]);
                sendResponse(true, [], 'Service updated successfully.');
            } else {
                $stmt = $pdo->prepare('
                    INSERT INTO services (service_name, description, price, status, created_by)
                    VALUES (?, ?, ?, ?, ?)
                ');
                $stmt->execute([$service_name, $description, $price, $status, $user_id]);
                sendResponse(true, [], 'Service created successfully.');
            }
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }

    // Admin: Delete service
    } elseif ($action === 'delete') {
        if ($role !== 'admin') {
            sendResponse(false, [], 'Admin authorization required.', 403);
        }

        $service_id = intval($input['service_id'] ?? 0);
        if (empty($service_id)) {
            sendResponse(false, [], 'Service ID is required.', 400);
        }

        try {
            $stmt = $pdo->prepare('DELETE FROM services WHERE service_id = ?');
            $stmt->execute([$service_id]);
            sendResponse(true, [], 'Service deleted successfully.');
        } catch (PDOException $e) {
            if ($e->getCode() == '23000') {
                sendResponse(false, [], 'Cannot delete service. There are active service requests linked to this service.', 400);
            } else {
                sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
            }
        }
    } else {
        sendResponse(false, [], 'Action not found.', 400);
    }
} else {
    sendResponse(false, [], 'Method not allowed.', 405);
}
?>
