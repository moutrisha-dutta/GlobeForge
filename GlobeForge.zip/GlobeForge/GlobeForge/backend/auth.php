<?php
// GlobeForge Auth Controller API
// File: backend/auth.php

require_once 'config.php';

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read JSON payload if content-type is json
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    if ($action === 'login') {
        $email = trim($input['email'] ?? '');
        $password = $input['password'] ?? '';

        if (empty($email) || empty($password)) {
            sendResponse(false, [], 'Email and password are required.', 400);
        }

        try {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                if ($user['status'] !== 'active') {
                    sendResponse(false, [], 'Your account is inactive. Please contact the administrator.', 403);
                }

                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['full_name'] = $user['full_name'];

                sendResponse(true, [
                    'user_id' => $user['user_id'],
                    'role' => $user['role'],
                    'email' => $user['email'],
                    'full_name' => $user['full_name']
                ], 'Logged in successfully.');
            } else {
                sendResponse(false, [], 'Invalid email or password.', 401);
            }
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }

    } elseif ($action === 'register') {
        $email = trim($input['email'] ?? '');
        $mobile = trim($input['mobile_number'] ?? '');
        $full_name = trim($input['full_name'] ?? '');
        $password = $input['password'] ?? '';

        if (empty($email) || empty($mobile) || empty($full_name) || empty($password)) {
            sendResponse(false, [], 'All fields are required.', 400);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendResponse(false, [], 'Invalid email address.', 400);
        }

        if (strlen($password) < 6) {
            sendResponse(false, [], 'Password must be at least 6 characters.', 400);
        }

        try {
            // Check duplicate
            $check_stmt = $pdo->prepare('SELECT email, mobile_number FROM users WHERE email = ? OR mobile_number = ? LIMIT 1');
            $check_stmt->execute([$email, $mobile]);
            $existing = $check_stmt->fetch();

            if ($existing) {
                if ($existing['email'] === $email) {
                    sendResponse(false, [], 'Email is already registered.', 400);
                } else {
                    sendResponse(false, [], 'Mobile number is already registered.', 400);
                }
            }

            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $insert_stmt = $pdo->prepare('
                INSERT INTO users (role, email, mobile_number, full_name, password_hash, status)
                VALUES (\'customer\', ?, ?, ?, ?, \'active\')
            ');
            $insert_stmt->execute([$email, $mobile, $full_name, $password_hash]);

            sendResponse(true, [], 'Registration successful! You can now log in.');
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }

    } elseif ($action === 'logout') {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        sendResponse(true, [], 'Logged out successfully.');
    } else {
        sendResponse(false, [], 'Invalid action requested.', 400);
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'status') {
        if (isset($_SESSION['user_id'])) {
            sendResponse(true, [
                'user_id' => $_SESSION['user_id'],
                'role' => $_SESSION['role'],
                'email' => $_SESSION['email'],
                'full_name' => $_SESSION['full_name']
            ], 'Authenticated.');
        } else {
            sendResponse(false, [], 'Unauthenticated.');
        }
    } else {
        sendResponse(false, [], 'Invalid action requested.', 400);
    }
} else {
    sendResponse(false, [], 'Unsupported HTTP method.', 405);
}
?>
