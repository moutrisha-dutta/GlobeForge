<?php
// GlobeForge Contact Message Handler API
// File: backend/contact.php

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    
    $name = trim($input['name'] ?? '');
    $email = trim($input['email'] ?? '');
    $subject = trim($input['subject'] ?? '');
    $message = trim($input['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        sendResponse(false, [], 'All fields are required.', 400);
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sendResponse(false, [], 'Invalid email address.', 400);
    }
    
    // Log the contact inquiry for admin records
    $logEntry = sprintf(
        "[%s] Name: %s | Email: %s | Subject: %s\nMessage: %s\n--------------------\n",
        date('Y-m-d H:i:s'), $name, $email, $subject, $message
    );
    file_put_contents(__DIR__ . '/contact_submissions.log', $logEntry, FILE_APPEND);
    
    sendResponse(true, [], 'Thank you! Your message has been received. We will contact you soon.');
} else {
    sendResponse(false, [], 'Method not allowed.', 405);
}
?>
