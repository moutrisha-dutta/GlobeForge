<?php
// GlobeForge Profile Operations API
// File: backend/profile.php

require_once 'config.php';

// Authorization required
if (!isset($_SESSION['user_id'])) {
    sendResponse(false, [], 'Unauthorized.', 401);
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    if ($action === 'update') {
        $full_name = trim($input['full_name'] ?? '');
        $email = trim($input['email'] ?? '');
        $mobile = trim($input['mobile_number'] ?? '');
        $password = $input['password'] ?? '';

        if (empty($full_name) || empty($email) || empty($mobile)) {
            sendResponse(false, [], 'Name, Email, and Mobile number are required fields.', 400);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendResponse(false, [], 'Invalid email address.', 400);
        }

        try {
            // Check duplicates
            $check_stmt = $pdo->prepare('SELECT user_id, email, mobile_number FROM users WHERE (email = ? OR mobile_number = ?) AND user_id != ? LIMIT 1');
            $check_stmt->execute([$email, $mobile, $user_id]);
            $duplicate = $check_stmt->fetch();

            if ($duplicate) {
                if ($duplicate['email'] === $email) {
                    sendResponse(false, [], 'Email address is already in use by another account.', 400);
                } else {
                    sendResponse(false, [], 'Mobile number is already in use by another account.', 400);
                }
            }

            if (!empty($password)) {
                if (strlen($password) < 6) {
                    sendResponse(false, [], 'New password must be at least 6 characters.', 400);
                }
                $password_hash = password_hash($password, PASSWORD_BCRYPT);
                $update_stmt = $pdo->prepare('
                    UPDATE users 
                    SET full_name = ?, email = ?, mobile_number = ?, password_hash = ?
                    WHERE user_id = ?
                ');
                $update_stmt->execute([$full_name, $email, $mobile, $password_hash, $user_id]);
            } else {
                $update_stmt = $pdo->prepare('
                    UPDATE users 
                    SET full_name = ?, email = ?, mobile_number = ?
                    WHERE user_id = ?
                ');
                $update_stmt->execute([$full_name, $email, $mobile, $user_id]);
            }

            // Sync session
            $_SESSION['full_name'] = $full_name;
            $_SESSION['email'] = $email;

            sendResponse(true, [
                'full_name' => $full_name,
                'email' => $email
            ], 'Profile details updated successfully.');
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }

    } elseif ($action === 'delete') {
        if ($role !== 'customer') {
            sendResponse(false, [], 'Administrative accounts cannot be self-deleted.', 403);
        }

        try {
            $delete_stmt = $pdo->prepare('DELETE FROM users WHERE user_id = ?');
            $delete_stmt->execute([$user_id]);

            // Destroy session
            $_SESSION = [];
            session_destroy();
            sendResponse(true, [], 'Account deleted successfully.');
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }
    } else {
        sendResponse(false, [], 'Action not found.', 400);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->prepare('SELECT full_name, email, mobile_number FROM users WHERE user_id = ? LIMIT 1');
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        if ($user) {
            sendResponse(true, $user, 'Profile retrieved successfully.');
        } else {
            sendResponse(false, [], 'User account not found.', 404);
        }
    } catch (PDOException $e) {
        sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
    }
} else {
    sendResponse(false, [], 'Method not allowed.', 405);
}
?>
