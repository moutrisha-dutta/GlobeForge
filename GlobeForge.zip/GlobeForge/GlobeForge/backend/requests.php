<?php
// GlobeForge Request Approvals Moderation API
// File: backend/requests.php

require_once 'config.php';

// Enforce Admin Authorization
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    sendResponse(false, [], 'Unauthorized access.', 403);
}

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'moderate') {
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
    
    $request_id = intval($input['request_id'] ?? 0);
    $status = $input['status'] ?? 'pending';
    $remarks = trim($input['admin_remarks'] ?? '');
    $approved_by = $_SESSION['user_id'];

    if (empty($request_id)) {
        sendResponse(false, [], 'Request ID is required.', 400);
    }

    if (!in_array($status, ['pending', 'confirmed', 'successful'])) {
        sendResponse(false, [], 'Invalid status value.', 400);
    }

    try {
        $update_stmt = $pdo->prepare('
            UPDATE service_requests 
            SET status = ?, admin_remarks = ?, approved_by = ?
            WHERE request_id = ?
        ');
        $update_stmt->execute([$status, $remarks, $approved_by, $request_id]);
        
        sendResponse(true, [], 'Service request updated successfully.');
    } catch (PDOException $e) {
        sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
    }
} else {
    sendResponse(false, [], 'Method/Action not supported.', 400);
}
?>
