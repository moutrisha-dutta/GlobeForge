<?php
// GlobeForge Employee Directory Controller API
// File: backend/employees.php

require_once 'config.php';

$action = $_GET['action'] ?? '';

// Public Employee verification search
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'verify') {
    $emp_id = trim($_GET['emp_id'] ?? '');
    if (empty($emp_id)) {
        sendResponse(false, [], 'Employee ID is required.', 400);
    }
    
    try {
        $stmt = $pdo->prepare('SELECT emp_id, full_name, dob, address, email, phone_number, status FROM employees WHERE emp_id = ? LIMIT 1');
        $stmt->execute([$emp_id]);
        $employee = $stmt->fetch();
        
        if ($employee) {
            sendResponse(true, $employee, 'Employee verified successfully.');
        } else {
            sendResponse(false, [], 'No employee found with this ID.', 404);
        }
    } catch (PDOException $e) {
        sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
    }
}

// -------------------------------------------------------------
// Admin authorization required for remaining endpoints
// -------------------------------------------------------------
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    sendResponse(false, [], 'Unauthorized access.', 403);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'list') {
        try {
            $stmt = $pdo->query('SELECT * FROM employees ORDER BY created_at DESC');
            $employees = $stmt->fetchAll();
            sendResponse(true, $employees, 'Staff directory loaded.');
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }
    } else {
        sendResponse(false, [], 'Action not found.', 400);
    }

} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    if ($action === 'save') {
        $emp_id = trim($input['emp_id'] ?? '');
        $full_name = trim($input['full_name'] ?? '');
        $dob = trim($input['dob'] ?? '');
        $address = trim($input['address'] ?? '');
        $email = trim($input['email'] ?? '');
        $phone_number = trim($input['phone_number'] ?? '');
        $status = $input['status'] ?? 'active';
        $is_edit = filter_var($input['is_edit'] ?? false, FILTER_VALIDATE_BOOLEAN);

        if (empty($emp_id) || empty($full_name) || empty($dob) || empty($address) || empty($email) || empty($phone_number)) {
            sendResponse(false, [], 'All fields are required.', 400);
        }

        try {
            if ($is_edit) {
                // Edit: Verify duplicate email excluding this Employee ID
                $check_stmt = $pdo->prepare('SELECT emp_id FROM employees WHERE email = ? AND emp_id != ? LIMIT 1');
                $check_stmt->execute([$email, $emp_id]);
                if ($check_stmt->fetch()) {
                    sendResponse(false, [], 'Email address is already in use by another employee.', 400);
                }

                $update_stmt = $pdo->prepare('
                    UPDATE employees 
                    SET full_name = ?, dob = ?, address = ?, email = ?, phone_number = ?, status = ?
                    WHERE emp_id = ?
                ');
                $update_stmt->execute([$full_name, $dob, $address, $email, $phone_number, $status, $emp_id]);
                sendResponse(true, [], 'Employee profile updated successfully.');
            } else {
                // New: Check unique Employee ID & Email
                $check_stmt = $pdo->prepare('SELECT emp_id, email FROM employees WHERE emp_id = ? OR email = ? LIMIT 1');
                $check_stmt->execute([$emp_id, $email]);
                $existing = $check_stmt->fetch();

                if ($existing) {
                    if ($existing['emp_id'] === $emp_id) {
                        sendResponse(false, [], 'Employee ID is already registered.', 400);
                    } else {
                        sendResponse(false, [], 'Email address is already registered to another employee.', 400);
                    }
                }

                $insert_stmt = $pdo->prepare('
                    INSERT INTO employees (emp_id, full_name, dob, address, email, phone_number, status, created_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ');
                $insert_stmt->execute([$emp_id, $full_name, $dob, $address, $email, $phone_number, $status, $_SESSION['user_id']]);
                sendResponse(true, [], 'Employee registered successfully.');
            }
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }

    } elseif ($action === 'delete') {
        $emp_id = trim($input['emp_id'] ?? '');
        if (empty($emp_id)) {
            sendResponse(false, [], 'Employee ID is required.', 400);
        }

        try {
            $delete_stmt = $pdo->prepare('DELETE FROM employees WHERE emp_id = ?');
            $delete_stmt->execute([$emp_id]);
            sendResponse(true, [], 'Employee deleted successfully.');
        } catch (PDOException $e) {
            sendResponse(false, [], 'Database error: ' . $e->getMessage(), 500);
        }
    } else {
        sendResponse(false, [], 'Action not found.', 400);
    }
} else {
    sendResponse(false, [], 'Method not allowed.', 405);
}
?>
