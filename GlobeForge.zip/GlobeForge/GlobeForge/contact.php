<?php
// GlobeForge Contact Page & Form Handler
// File: contact.php

$pageTitle = "Contact Us";
require_once 'config.php';

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } else {
        try {
            $stmt = $pdo->prepare('INSERT INTO contact_inquiries (name, email, subject, message) VALUES (?, ?, ?, ?)');
            $stmt->execute([$name, $email, $subject, $message]);
            
            // Log to file as a secondary backup
            $logEntry = sprintf(
                "[%s] Name: %s | Email: %s | Subject: %s\nMessage: %s\n--------------------\n",
                date('Y-m-d H:i:s'), $name, $email, $subject, $message
            );
            file_put_contents(__DIR__ . '/contact_submissions.log', $logEntry, FILE_APPEND);
            
            $success = 'Thank you! Your message has been received. We will contact you soon.';
            
            // Reset form variables
            $name = $email = $subject = $message = '';
        } catch (PDOException $e) {
            $error = 'Failed to send message: ' . $e->getMessage();
        }
    }
}

require_once 'header.php';
?>

<!-- Hero Header -->
<div class="hero" style="padding: 2rem 1rem;">
    <h1>Contact GlobeForge</h1>
    <p>Have inquiries or want custom enterprise packages? Get in touch with our team today.</p>
</div>

<div class="home-grid" style="margin-bottom: 3rem;">
    <!-- Contact Info Column -->
    <div class="glass-container" style="display: flex; flex-direction: column; justify-content: space-between; height: 100%;">
        <div>
            <h2 style="font-size: 1.75rem; margin-bottom: 1rem; background: linear-gradient(to right, #ffffff, #a855f7); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Contact Information</h2>
            <p style="color: var(--text-secondary); margin-bottom: 2rem; font-size: 0.9rem;">Reach out directly using the options below or visit our headquarters.</p>

            <div class="contact-info-list">
                <!-- Support Line 1 -->
                <div class="contact-number-card">
                    <div class="contact-number-info">
                        <span class="phone-label">Primary Support</span>
                        <span class="phone-digits">+91 70473 16771</span>
                    </div>
                    <div class="contact-number-actions">
                        <a href="tel:+917047316771" class="action-btn call-action" title="Call support line 1">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        </a>
                        <a href="https://wa.me/917047316771" target="_blank" rel="noopener noreferrer" class="action-btn wa-action" title="WhatsApp support line 1">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                        </a>
                    </div>
                </div>

                <!-- Support Line 2 -->
                <div class="contact-number-card">
                    <div class="contact-number-info">
                        <span class="phone-label">Secondary Support</span>
                        <span class="phone-digits">+91 824 034 5541</span>
                    </div>
                    <div class="contact-number-actions">
                        <a href="tel:+918240345541" class="action-btn call-action" title="Call support line 2">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        </a>
                        <a href="https://wa.me/918240345541" target="_blank" rel="noopener noreferrer" class="action-btn wa-action" title="WhatsApp support line 2">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
                        </a>
                    </div>
                </div>

                <!-- Location Option -->
                <div class="contact-info-item location-item">
                    <div class="contact-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                    </div>
                    <div class="contact-details">
                        <h3>Our Address</h3>
                        <p style="font-size: 0.85rem; line-height: 1.4;">Ramachandrapur Narendrapur, Boral Bagher Kolkata103, Rajpur Sonarpur, Kolkata, West Bengal 700103</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="contact-map-container">
            <iframe 
                src="https://maps.google.com/maps?q=Ramachandrapur%20Narendrapur%2C%20Boral%20Bagher%20Kolkata103%2C%20Rajpur%20Sonarpur%2C%20Kolkata%2C%20West%20Bengal%20700103&t=&z=15&ie=UTF8&iwloc=&output=embed" 
                width="100%" 
                height="100%" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>

    <!-- Inquiry Form Column -->
    <div class="glass-container" style="margin-bottom: 0;">
        <h2 style="font-size: 1.75rem; margin-bottom: 1rem; text-align: center; background: linear-gradient(to right, #ffffff, #a855f7); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Send Us A Message</h2>
        <p style="color: var(--text-secondary); text-align: center; margin-bottom: 2rem; font-size: 0.9rem;">Submit your message below. Our administrative team will verify details and reach back.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger mb-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                <span><?php echo e($error); ?></span>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success mb-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                <span><?php echo e($success); ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="contact.php" autocomplete="off">
            <div class="form-group">
                <label for="name">Your Name *</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="e.g. John Doe" value="<?php echo isset($name) ? e($name) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="name@example.com" value="<?php echo isset($email) ? e($email) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="subject">Subject *</label>
                <input type="text" name="subject" id="subject" class="form-control" placeholder="e.g. Requesting Custom Service Quote" value="<?php echo isset($subject) ? e($subject) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="message">Message *</label>
                <textarea name="message" id="message" class="form-control" placeholder="Type your message details here..." required><?php echo isset($message) ? e($message) : ''; ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 0.25rem;"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                Submit Inquiry
            </button>
        </form>
    </div>
</div>

<?php
require_once 'footer.php';
?>
