<?php
// GlobeForge Homepage
// File: index.php

$pageTitle = "Home";
require_once 'config.php';

// Handle Employee Verification
$employee = null;
$verify_error = null;
if (isset($_GET['emp_id'])) {
    $emp_id = trim($_GET['emp_id']);
    if (empty($emp_id)) {
        $verify_error = "Employee ID is required.";
    } else {
        try {
            $stmt = $pdo->prepare('SELECT * FROM employees WHERE emp_id = ? LIMIT 1');
            $stmt->execute([$emp_id]);
            $employee = $stmt->fetch();
            if (!$employee) {
                $verify_error = "No active employee found with ID: " . htmlspecialchars($emp_id);
            }
        } catch (PDOException $e) {
            $verify_error = "Database lookup failed: " . $e->getMessage();
        }
    }
}

// Fetch Services Catalog
$services = [];
try {
    $stmt = $pdo->prepare('SELECT * FROM services WHERE status = "active" ORDER BY service_name ASC');
    $stmt->execute();
    $services = $stmt->fetchAll();
} catch (PDOException $e) {
    // Silent fail or alert
    $services_error = "Failed to load services: " . $e->getMessage();
}

require_once 'header.php';
?>

<!-- Hero Section -->
<div class="hero">
    <h1>Forging Global Enterprise Solutions</h1>
    <p>Secure login portals, custom workflow tracking, and seamless service procurement engineered for the modern workplace.</p>
    <div class="d-flex justify-center gap-2 text-center" style="justify-content: center;">
        <?php if (!isset($_SESSION['user_id'])): ?>
            <a href="login.php" class="btn btn-primary" style="text-decoration: none;">Get Started</a>
        <?php else: ?>
            <a href="<?php echo $_SESSION['role'] === 'admin' ? 'admin_dashboard.php' : 'customer_dashboard.php'; ?>" class="btn btn-primary" style="text-decoration: none;">Go to Dashboard</a>
        <?php endif; ?>
        <a href="#services-section" class="btn btn-secondary" style="text-decoration: none;">Explore Services</a>
    </div>
</div>

<!-- Main Home Grid -->
<div class="home-grid">
    <!-- Employee Verification Card -->
    <div class="glass-container verification-card" id="employee-verification">
        <h2>
            <span class="verification-icon">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline></svg>
            </span>
            Employee Verification
        </h2>
        <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">
            Verify employee identity, active credentials, and system deployment status instantly using a valid Employee ID.
        </p>

        <form method="GET" action="index.php#employee-verification" autocomplete="off">
            <div class="form-group">
                <label for="emp_id">Employee ID *</label>
                <div class="d-flex gap-2">
                    <input type="text" name="emp_id" id="emp_id" class="form-control" placeholder="e.g. EMP0001" value="<?php echo isset($_GET['emp_id']) ? e($_GET['emp_id']) : ''; ?>" required>
                    <button type="submit" class="btn btn-primary">Verify</button>
                </div>
            </div>
        </form>

        <?php if ($employee): ?>
            <div class="employee-info-card mt-2">
                <h3>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                    Verification Results
                </h3>
                <div class="employee-details-grid">
                    <div class="employee-detail-item">
                        <strong>Full Name</strong>
                        <span><?php echo e($employee['full_name']); ?></span>
                    </div>
                    <div class="employee-detail-item">
                        <strong>Employee ID</strong>
                        <span><?php echo e($employee['emp_id']); ?></span>
                    </div>
                    <div class="employee-detail-item">
                        <strong>Date of Birth</strong>
                        <span><?php echo e($employee['dob']); ?></span>
                    </div>
                    <div class="employee-detail-item">
                        <strong>Deployment Status</strong>
                        <span class="badge badge-<?php echo $employee['status'] === 'active' ? 'active' : 'inactive'; ?>">
                            <?php echo e($employee['status']); ?>
                        </span>
                    </div>
                    <div class="employee-detail-item">
                        <strong>Email Address</strong>
                        <span><?php echo e($employee['email']); ?></span>
                    </div>
                    <div class="employee-detail-item">
                        <strong>Phone Number</strong>
                        <span><?php echo e($employee['phone_number']); ?></span>
                    </div>
                    <div class="employee-detail-item" style="grid-column: span 2;">
                        <strong>Address</strong>
                        <span><?php echo e($employee['address']); ?></span>
                    </div>
                </div>
            </div>
        <?php elseif ($verify_error): ?>
            <div class="alert alert-danger mt-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                <span><?php echo e($verify_error); ?></span>
            </div>
        <?php endif; ?>
    </div>

    <!-- About Card -->
    <div class="glass-container d-flex flex-column justify-center" style="justify-content: center;">
        <h2>About GlobeForge</h2>
        <p class="mt-2" style="color: var(--text-secondary);">
            GlobeForge provides full lifecycle deployment tracking for premium services. Customers can register directly to browse our enterprise services, place requests, and track real-time approval status from our administration team.
        </p>
        <p class="mt-2" style="color: var(--text-secondary);">
            If you are a system customer, register today to gain full access to the portal dashboard and configure your profile constraints dynamically.
        </p>
        <?php if (!isset($_SESSION['user_id'])): ?>
            <div class="mt-2">
                <a href="register.php" class="btn btn-secondary" style="width: 100%; text-decoration: none; text-align: center;">Create Customer Account</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Services Section -->
<div class="glass-container" id="services-section" style="margin-top: 2rem;">
    <h2 style="font-size: 2rem; margin-bottom: 0.5rem; text-align: center;">Our Service Offerings</h2>
    <p style="color: var(--text-secondary); text-align: center; margin-bottom: 2.5rem; max-width: 600px; margin-left: auto; margin-right: auto;">
        Browse our catalog of professional services. Log in to place a service request.
    </p>

    <div class="services-grid">
        <?php if (isset($services_error)): ?>
            <p class="text-center" style="color: var(--danger); width: 100%;"><?php echo e($services_error); ?></p>
        <?php elseif (empty($services)): ?>
            <p class="text-center" style="color: var(--text-muted); width: 100%;">No services are currently configured in the database.</p>
        <?php else: ?>
            <?php foreach ($services as $service): ?>
                <div class="service-card">
                    <div>
                        <h3><?php echo e($service['service_name']); ?></h3>
                        <p><?php echo e($service['description'] ?: 'No description provided.'); ?></p>
                    </div>
                    <div class="service-card-footer">
                        <span class="service-price">
                            <?php echo $service['price'] !== null ? '$' . number_format($service['price'], 2) : 'Quote'; ?>
                        </span>
                        
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <?php if ($_SESSION['role'] === 'customer'): ?>
                                <form method="POST" action="customer_dashboard.php">
                                    <input type="hidden" name="service_id" value="<?php echo $service['service_id']; ?>">
                                    <input type="hidden" name="action" value="request_service">
                                    <button type="submit" class="btn btn-primary btn-sm">Request Service</button>
                                </form>
                            <?php else: ?>
                                <span class="badge badge-active">Admin View</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-secondary btn-sm" style="text-decoration: none;">Login to Request</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<?php
require_once 'footer.php';
?>
