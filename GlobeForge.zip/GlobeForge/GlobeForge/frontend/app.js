// GlobeForge Frontend Master Script
// File: frontend/app.js

document.addEventListener('DOMContentLoaded', () => {
    // 1. Load Session & Layout Initialization
    checkSessionAndBuildLayout();
});

// Global state holding logged in user details
let currentUser = null;

// Helper to make API calls with correct JSON formatting
async function fetchAPI(url, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {}
        };
        
        if (data) {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(data);
        }
        
        const response = await fetch(url, options);
        const result = await response.json();
        
        if (!response.ok) {
            throw new Error(result.message || 'API request failed.');
        }
        
        return result;
    } catch (error) {
        console.error('Fetch Error:', error);
        throw error;
    }
}

// Injects standard bootstrap notices
function showNotice(type, message, containerId = 'notice-container') {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    const icon = type === 'success' 
        ? `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>`
        : `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`;
        
    container.innerHTML = `
        <div class="alert alert-${type === 'success' ? 'success' : 'danger'}">
            ${icon}
            <span>${escapeHTML(message)}</span>
        </div>
    `;
}

// HTML escape helper
function escapeHTML(str) {
    if (!str) return '';
    return str.replace(/[&<>'"]/g, 
        tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
    );
}

// Redirect helpers
function redirectTo(path) {
    window.location.href = path;
}

// Check session and dynamically inject Header & Footer
async function checkSessionAndBuildLayout() {
    try {
        const response = await fetchAPI('../backend/auth.php?action=status');
        if (response.success) {
            currentUser = response.data;
        }
    } catch (e) {
        // Leave user as null (guest)
    }

    // Auth Route guards
    const currentPage = basename(window.location.pathname);
    if (currentUser) {
        // If on guest login/register page, redirect to correct dashboards
        if (currentPage === 'login.html' || currentPage === 'register.html') {
            if (currentUser.role === 'admin') {
                redirectTo('admin_dashboard.html');
            } else {
                redirectTo('customer_dashboard.html');
            }
            return;
        }
        
        // If customer tries to access admin pages
        if (currentPage.startsWith('admin_') && currentUser.role !== 'admin') {
            redirectTo('index.html');
            return;
        }
        
        // If admin tries to access customer dashboard
        if (currentPage === 'customer_dashboard.html' && currentUser.role !== 'customer') {
            redirectTo('admin_dashboard.html');
            return;
        }
    } else {
        // If guest tries to access dashboard pages
        if (currentPage !== 'index.html' && currentPage !== 'login.html' && currentPage !== 'register.html' && currentPage !== 'about.html' && currentPage !== 'contact.html' && currentPage !== '') {
            redirectTo('login.html');
            return;
        }
    }

    renderNavbar(currentUser);
    renderFooter();
    
    // Trigger localized page functions
    triggerPageScript();
}

function basename(path) {
    return path.substring(path.lastIndexOf('/') + 1);
}

// Render dynamic navbar
function renderNavbar(user) {
    const headerEl = document.createElement('header');
    const currentPage = basename(window.location.pathname);
    const activeClass = (page) => (currentPage === page || (currentPage === '' && page === 'index.html')) ? 'active' : '';

    let navLinksHTML = `
        <li><a href="index.html" class="${activeClass('index.html')}">Home</a></li>
        <li><a href="about.html" class="${activeClass('about.html')}">About Us</a></li>
        <li><a href="contact.html" class="${activeClass('contact.html')}">Contact Us</a></li>
    `;
    
    if (user) {
        if (user.role === 'admin') {
            navLinksHTML += `
                <li><a href="admin_dashboard.html" class="${activeClass('admin_dashboard.html')}">Dashboard</a></li>
                <li><a href="admin_services.html" class="${activeClass('admin_services.html')}">Services</a></li>
                <li><a href="admin_employees.html" class="${activeClass('admin_employees.html')}">Employees</a></li>
                <li><a href="admin_requests.html" class="${activeClass('admin_requests.html')}">Approvals</a></li>
                <li><a href="admin_profile.html" class="${activeClass('admin_profile.html')}">Profile</a></li>
            `;
        } else {
            navLinksHTML += `
                <li><a href="customer_dashboard.html" class="${activeClass('customer_dashboard.html')}">My Services</a></li>
                <li><a href="customer_profile.html" class="${activeClass('customer_profile.html')}">My Profile</a></li>
            `;
        }
        navLinksHTML += `
            <li class="user-tag">
                <span class="role-badge">${escapeHTML(user.role)}</span>
                ${escapeHTML(user.full_name)}
            </li>
            <li><button id="logout-btn" class="btn btn-secondary btn-sm" style="padding: 0.35rem 0.75rem;">Logout</button></li>
        `;
    } else {
        navLinksHTML += `
            <li><a href="login.html" class="btn btn-secondary btn-sm" style="padding: 0.35rem 0.75rem;">Login</a></li>
            <li><a href="register.html" class="btn btn-primary btn-sm" style="padding: 0.35rem 0.75rem; color: #ffffff;">Register</a></li>
        `;
    }

    headerEl.innerHTML = `
        <nav class="navbar">
            <div class="logo-container">
                <a href="index.html">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 0.25rem;"><circle cx="12" cy="12" r="10"></circle><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"></path><path d="M2 12h20"></path></svg>
                    GlobeForge
                </a>
            </div>
            <ul class="nav-links">
                ${navLinksHTML}
            </ul>
        </nav>
    `;
    
    document.body.prepend(headerEl);
    
    // Add logout handler
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            try {
                const res = await fetchAPI('../backend/auth.php?action=logout', 'POST');
                if (res.success) {
                    redirectTo('index.html');
                }
            } catch (e) {
                alert('Logout failed: ' + e.message);
            }
        });
    }
}

// Render dynamic footer
function renderFooter() {
    const footerEl = document.createElement('footer');
    footerEl.innerHTML = `
        <div class="footer-content">
            <p>&copy; ${new Date().getFullYear()} GlobeForge. All rights reserved. Premium enterprise solutions.</p>
        </div>
    `;
    document.body.appendChild(footerEl);
}

// -------------------------------------------------------------
// Route-Specific Page Logic Router
// -------------------------------------------------------------
function triggerPageScript() {
    const currentPage = basename(window.location.pathname);
    
    if (currentPage === 'index.html' || currentPage === '') {
        initHomePage();
    } else if (currentPage === 'login.html') {
        initLoginPage();
    } else if (currentPage === 'register.html') {
        initRegisterPage();
    } else if (currentPage === 'customer_dashboard.html') {
        initCustomerDashboard();
    } else if (currentPage === 'customer_profile.html') {
        initCustomerProfile();
    } else if (currentPage === 'admin_dashboard.html') {
        initAdminDashboard();
    } else if (currentPage === 'admin_services.html') {
        initAdminServices();
    } else if (currentPage === 'admin_employees.html') {
        initAdminEmployees();
    } else if (currentPage === 'admin_requests.html') {
        initAdminRequests();
    } else if (currentPage === 'admin_profile.html') {
        initAdminProfile();
    } else if (currentPage === 'contact.html') {
        initContactPage();
    }
}

// -------------------------------------------------------------
// Page Scripts
// -------------------------------------------------------------

// HOMEPAGE
function initHomePage() {
    // 1. Fetch and render active services catalog
    const servicesGrid = document.getElementById('services-grid');
    if (servicesGrid) {
        fetchAPI('../backend/services.php?action=list')
            .then(res => {
                if (res.success && res.data.length > 0) {
                    servicesGrid.innerHTML = res.data.map(service => `
                        <div class="service-card">
                            <div>
                                <h3>${escapeHTML(service.service_name)}</h3>
                                <p>${escapeHTML(service.description || 'No description provided.')}</p>
                            </div>
                            <div class="service-card-footer">
                                <span class="service-price">${service.price !== null ? '$' + parseFloat(service.price).toFixed(2) : 'Quote'}</span>
                                ${currentUser && currentUser.role === 'customer' 
                                    ? `<button onclick="requestService(${service.service_id})" class="btn btn-primary btn-sm">Request Service</button>`
                                    : currentUser && currentUser.role === 'admin'
                                        ? `<span class="badge badge-active">Admin View</span>`
                                        : `<a href="login.html" class="btn btn-secondary btn-sm">Login to Request</a>`
                                }
                            </div>
                        </div>
                    `).join('');
                } else {
                    servicesGrid.innerHTML = `<p class="text-center" style="color: var(--text-muted); width:100%;">No services are currently configured in the database.</p>`;
                }
            })
            .catch(err => {
                servicesGrid.innerHTML = `<p class="text-center" style="color: var(--danger); width:100%;">Error loading service catalog.</p>`;
            });
    }

    // 2. Employee Verification lookup
    const verifyForm = document.getElementById('verify-form');
    const resultCard = document.getElementById('verification-results');
    
    if (verifyForm) {
        verifyForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const empId = document.getElementById('emp_id').value.trim();
            resultCard.style.display = 'none';
            resultCard.innerHTML = '';
            
            try {
                const res = await fetchAPI(`../backend/employees.php?action=verify&emp_id=${encodeURIComponent(empId)}`);
                if (res.success && res.data) {
                    resultCard.style.display = 'block';
                    resultCard.innerHTML = `
                        <div class="employee-info-card mt-2">
                            <h3>
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
                                Verification Results
                            </h3>
                            <div class="employee-details-grid">
                                <div class="employee-detail-item">
                                    <strong>Full Name</strong>
                                    <span>${escapeHTML(res.data.full_name)}</span>
                                </div>
                                <div class="employee-detail-item">
                                    <strong>Employee ID</strong>
                                    <span>${escapeHTML(res.data.emp_id)}</span>
                                </div>
                                <div class="employee-detail-item">
                                    <strong>Date of Birth</strong>
                                    <span>${escapeHTML(res.data.dob)}</span>
                                </div>
                                <div class="employee-detail-item">
                                    <strong>Deployment Status</strong>
                                    <span class="badge badge-${res.data.status === 'active' ? 'active' : 'inactive'}">
                                        ${escapeHTML(res.data.status)}
                                    </span>
                                </div>
                                <div class="employee-detail-item">
                                    <strong>Email Address</strong>
                                    <span>${escapeHTML(res.data.email)}</span>
                                </div>
                                <div class="employee-detail-item">
                                    <strong>Phone Number</strong>
                                    <span>${escapeHTML(res.data.phone_number)}</span>
                                </div>
                                <div class="employee-detail-item" style="grid-column: span 2;">
                                    <strong>Address</strong>
                                    <span>${escapeHTML(res.data.address)}</span>
                                </div>
                            </div>
                        </div>
                    `;
                }
            } catch (err) {
                resultCard.style.display = 'block';
                resultCard.innerHTML = `
                    <div class="alert alert-danger mt-2">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                        <span>${escapeHTML(err.message)}</span>
                    </div>
                `;
            }
        });
    }
}

// Request service globally from catalog cards
async function requestService(serviceId) {
    try {
        const res = await fetchAPI('../backend/services.php?action=request_service', 'POST', { service_id: serviceId });
        if (res.success) {
            alert(res.message);
            // If on customer dashboard, reload logs
            if (basename(window.location.pathname) === 'customer_dashboard.html') {
                loadCustomerRequests();
            }
        }
    } catch (e) {
        alert('Error: ' + e.message);
    }
}

// LOGIN PAGE
function initLoginPage() {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            
            try {
                const res = await fetchAPI('../backend/auth.php?action=login', 'POST', { email, password });
                if (res.success) {
                    if (res.data.role === 'admin') {
                        redirectTo('admin_dashboard.html');
                    } else {
                        redirectTo('customer_dashboard.html');
                    }
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
    }
}

// REGISTER PAGE
function initRegisterPage() {
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const full_name = document.getElementById('full_name').value.trim();
            const email = document.getElementById('email').value.trim();
            const mobile_number = document.getElementById('mobile_number').value.trim();
            const password = document.getElementById('password').value;
            
            try {
                const res = await fetchAPI('../backend/auth.php?action=register', 'POST', {
                    full_name, email, mobile_number, password
                });
                if (res.success) {
                    showNotice('success', res.message);
                    registerForm.reset();
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
    }
}

// CUSTOMER DASHBOARD
function initCustomerDashboard() {
    document.getElementById('customer-welcome-name').textContent = currentUser.full_name;
    loadCustomerRequests();
    loadCustomerCatalog();
}

async function loadCustomerRequests() {
    const requestsTableBody = document.getElementById('requests-table-body');
    if (!requestsTableBody) return;
    
    try {
        const res = await fetchAPI('../backend/services.php?action=requests');
        if (res.success && res.data.length > 0) {
            requestsTableBody.innerHTML = res.data.map(req => `
                <tr>
                    <td><strong>${escapeHTML(req.service_name)}</strong></td>
                    <td>${req.price !== null ? '$' + parseFloat(req.price).toFixed(2) : 'Quote Needed'}</td>
                    <td>${escapeHTML(req.requested_at)}</td>
                    <td>
                        <span class="badge badge-${escapeHTML(req.status)}">
                            ${escapeHTML(req.status)}
                        </span>
                    </td>
                    <td style="color: var(--text-secondary);">
                        ${req.admin_remarks ? escapeHTML(req.admin_remarks) : '<em>No remarks yet</em>'}
                    </td>
                </tr>
            `).join('');
        } else {
            requestsTableBody.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 2rem 0;">
                        You haven't requested any services yet. Choose a service from the catalog below!
                    </td>
                </tr>
            `;
        }
    } catch (e) {
        requestsTableBody.innerHTML = `<tr><td colspan="5" style="color: var(--danger); text-align: center;">Error loading service requests.</td></tr>`;
    }
}

async function loadCustomerCatalog() {
    const catalogGrid = document.getElementById('customer-catalog-grid');
    if (!catalogGrid) return;

    try {
        const res = await fetchAPI('../backend/services.php?action=list');
        if (res.success && res.data.length > 0) {
            catalogGrid.innerHTML = res.data.map(service => `
                <div class="service-card">
                    <div>
                        <h3>${escapeHTML(service.service_name)}</h3>
                        <p>${escapeHTML(service.description || 'No description.')}</p>
                    </div>
                    <div class="service-card-footer">
                        <span class="service-price">${service.price !== null ? '$' + parseFloat(service.price).toFixed(2) : 'Quote'}</span>
                        <button onclick="requestService(${service.service_id})" class="btn btn-primary btn-sm">Request Service</button>
                    </div>
                </div>
            `).join('');
        } else {
            catalogGrid.innerHTML = `<p style="color: var(--text-muted);">No services configured.</p>`;
        }
    } catch (e) {
        catalogGrid.innerHTML = `<p style="color: var(--danger);">Failed to load service catalog.</p>`;
    }
}

// CUSTOMER PROFILE
function initCustomerProfile() {
    const profileForm = document.getElementById('profile-form');
    const deleteForm = document.getElementById('delete-profile-form');
    
    if (profileForm) {
        // Fetch full user details from the backend profile API
        fetchAPI('../backend/profile.php')
            .then(res => {
                if (res.success && res.data) {
                    document.getElementById('full_name').value = res.data.full_name || '';
                    document.getElementById('email').value = res.data.email || '';
                    document.getElementById('mobile_number').value = res.data.mobile_number || '';
                }
            })
            .catch(err => {
                showNotice('danger', 'Error loading profile details: ' + err.message);
            });
    }

    if (profileForm) {
        profileForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const full_name = document.getElementById('full_name').value.trim();
            const email = document.getElementById('email').value.trim();
            const mobile_number = document.getElementById('mobile_number').value.trim();
            const password = document.getElementById('password').value;
            
            try {
                const res = await fetchAPI('../backend/profile.php?action=update', 'POST', {
                    full_name, email, mobile_number, password
                });
                if (res.success) {
                    showNotice('success', res.message);
                    currentUser.full_name = full_name;
                    currentUser.email = email;
                    document.querySelector('.user-tag').innerHTML = `
                        <span class="role-badge">${escapeHTML(currentUser.role)}</span>
                        ${escapeHTML(full_name)}
                    `;
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
    }

    if (deleteForm) {
        deleteForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!confirm('Are you absolutely sure you want to delete your profile? All service requests will be permanently lost.')) {
                return;
            }
            try {
                const res = await fetchAPI('../backend/profile.php?action=delete', 'POST');
                if (res.success) {
                    alert('Your account has been deleted.');
                    redirectTo('index.html');
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
    }
}

// ADMIN DASHBOARD
async function initAdminDashboard() {
    try {
        const res = await fetchAPI('../backend/services.php?action=requests');
        const servRes = await fetchAPI('../backend/services.php?action=list');
        const empRes = await fetchAPI('../backend/employees.php?action=list');
        
        // Count metrics
        const totalRequests = res.data ? res.data.length : 0;
        const pendingApprovals = res.data ? res.data.filter(r => r.status === 'pending').length : 0;
        const activeServices = servRes.data ? servRes.data.filter(s => s.status === 'active').length : 0;
        const staffCount = empRes.data ? empRes.data.length : 0;
        
        // Deduplicate registered customers count
        const uniqueCustomers = res.data ? [...new Set(res.data.map(r => r.customer_id))].length : 0;
        
        document.getElementById('metrics-customers').textContent = uniqueCustomers;
        document.getElementById('metrics-services').textContent = activeServices;
        document.getElementById('metrics-pending').textContent = pendingApprovals;
        document.getElementById('metrics-staff').textContent = staffCount;
    } catch(err) {
        console.error('Error loading admin metrics', err);
    }
}

// ADMIN SERVICES CRUD
let adminServicesData = [];
function initAdminServices() {
    loadAdminServices();
    
    const serviceForm = document.getElementById('service-form');
    if (serviceForm) {
        serviceForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const service_id = document.getElementById('service_id').value;
            const service_name = document.getElementById('service_name').value.trim();
            const description = document.getElementById('description').value.trim();
            const price = document.getElementById('price').value;
            const status = document.getElementById('status').value;
            const is_edit = !!service_id;
            
            try {
                const res = await fetchAPI('../backend/services.php?action=save', 'POST', {
                    service_id: service_id ? parseInt(service_id) : null,
                    service_name, description, price, status, is_edit
                });
                if (res.success) {
                    showNotice('success', res.message);
                    serviceForm.reset();
                    document.getElementById('service_id').value = '';
                    document.getElementById('form-title').textContent = 'Add New Service';
                    document.getElementById('submit-btn').textContent = 'Create Service';
                    document.getElementById('cancel-edit-btn').style.display = 'none';
                    loadAdminServices();
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
        
        document.getElementById('cancel-edit-btn').addEventListener('click', () => {
            serviceForm.reset();
            document.getElementById('service_id').value = '';
            document.getElementById('form-title').textContent = 'Add New Service';
            document.getElementById('submit-btn').textContent = 'Create Service';
            document.getElementById('cancel-edit-btn').style.display = 'none';
        });
    }
}

async function loadAdminServices() {
    const servicesTableBody = document.getElementById('services-table-body');
    if (!servicesTableBody) return;
    
    try {
        const res = await fetchAPI('../backend/services.php?action=list');
        if (res.success) {
            adminServicesData = res.data;
            if (adminServicesData.length > 0) {
                servicesTableBody.innerHTML = adminServicesData.map(service => `
                    <tr>
                        <td>
                            <strong>${escapeHTML(service.service_name)}</strong>
                            <div style="font-size: 0.8rem; color: var(--text-secondary); max-width: 250px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">
                                ${escapeHTML(service.description || 'No description')}
                            </div>
                        </td>
                        <td>${service.price !== null ? '$' + parseFloat(service.price).toFixed(2) : 'Quote'}</td>
                        <td>
                            <span class="badge badge-${escapeHTML(service.status)}">
                                ${escapeHTML(service.status)}
                            </span>
                        </td>
                        <td>
                            <div class="actions-cell">
                                <button onclick="editService(${service.service_id})" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;">Edit</button>
                                <button onclick="deleteService(${service.service_id})" class="btn btn-danger btn-sm" style="padding: 0.25rem 0.5rem;">Delete</button>
                            </div>
                        </td>
                    </tr>
                `).join('');
            } else {
                servicesTableBody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted);">No services registered.</td></tr>`;
            }
        }
    } catch (e) {
        servicesTableBody.innerHTML = `<tr><td colspan="4" style="color: var(--danger); text-align: center;">Error loading catalog.</td></tr>`;
    }
}

function editService(id) {
    const service = adminServicesData.find(s => s.service_id === id);
    if (!service) return;
    
    document.getElementById('service_id').value = service.service_id;
    document.getElementById('service_name').value = service.service_name;
    document.getElementById('description').value = service.description || '';
    document.getElementById('price').value = service.price !== null ? service.price : '';
    document.getElementById('status').value = service.status;
    
    document.getElementById('form-title').textContent = 'Edit Service';
    document.getElementById('submit-btn').textContent = 'Update Service';
    document.getElementById('cancel-edit-btn').style.display = 'inline-flex';
}

async function deleteService(id) {
    if (!confirm('Are you sure you want to delete this service?')) return;
    try {
        const res = await fetchAPI('../backend/services.php?action=delete', 'POST', { service_id: id });
        if (res.success) {
            alert(res.message);
            loadAdminServices();
        }
    } catch(err) {
        alert('Error: ' + err.message);
    }
}

// ADMIN EMPLOYEES CRUD
let adminEmployeesData = [];
function initAdminEmployees() {
    loadAdminEmployees();
    
    const employeeForm = document.getElementById('employee-form');
    if (employeeForm) {
        employeeForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const emp_id = document.getElementById('emp_id').value.trim();
            const full_name = document.getElementById('full_name').value.trim();
            const dob = document.getElementById('dob').value;
            const address = document.getElementById('address').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone_number = document.getElementById('phone_number').value.trim();
            const status = document.getElementById('status').value;
            const is_edit = document.getElementById('is_edit').value === 'true';
            
            try {
                const res = await fetchAPI('../backend/employees.php?action=save', 'POST', {
                    emp_id, full_name, dob, address, email, phone_number, status, is_edit
                });
                if (res.success) {
                    showNotice('success', res.message);
                    employeeForm.reset();
                    document.getElementById('emp_id').removeAttribute('readonly');
                    document.getElementById('emp_id').style.background = '';
                    document.getElementById('emp_id').style.cursor = '';
                    document.getElementById('is_edit').value = 'false';
                    document.getElementById('form-title').textContent = 'Register Employee';
                    document.getElementById('submit-btn').textContent = 'Register Employee';
                    document.getElementById('cancel-edit-btn').style.display = 'none';
                    loadAdminEmployees();
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
        
        document.getElementById('cancel-edit-btn').addEventListener('click', () => {
            employeeForm.reset();
            document.getElementById('emp_id').removeAttribute('readonly');
            document.getElementById('emp_id').style.background = '';
            document.getElementById('emp_id').style.cursor = '';
            document.getElementById('is_edit').value = 'false';
            document.getElementById('form-title').textContent = 'Register Employee';
            document.getElementById('submit-btn').textContent = 'Register Employee';
            document.getElementById('cancel-edit-btn').style.display = 'none';
        });
    }
}

async function loadAdminEmployees() {
    const employeesTableBody = document.getElementById('employees-table-body');
    if (!employeesTableBody) return;
    
    try {
        const res = await fetchAPI('../backend/employees.php?action=list');
        if (res.success) {
            adminEmployeesData = res.data;
            if (adminEmployeesData.length > 0) {
                employeesTableBody.innerHTML = adminEmployeesData.map(emp => `
                    <tr>
                        <td>
                            <strong>${escapeHTML(emp.full_name)}</strong>
                            <div style="font-size: 0.8rem; color: var(--text-secondary);">
                                ID: ${escapeHTML(emp.emp_id)}<br>
                                E: ${escapeHTML(emp.email)}<br>
                                P: ${escapeHTML(emp.phone_number)}
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-${escapeHTML(emp.status)}">
                                ${escapeHTML(emp.status)}
                            </span>
                        </td>
                        <td>
                            <div class="actions-cell">
                                <button onclick="editEmployee('${escapeHTML(emp.emp_id)}')" class="btn btn-secondary btn-sm" style="padding: 0.25rem 0.5rem;">Edit</button>
                                <button onclick="deleteEmployee('${escapeHTML(emp.emp_id)}')" class="btn btn-danger btn-sm" style="padding: 0.25rem 0.5rem;">Delete</button>
                            </div>
                        </td>
                    </tr>
                `).join('');
            } else {
                employeesTableBody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--text-muted);">No employees registered.</td></tr>`;
            }
        }
    } catch (e) {
        employeesTableBody.innerHTML = `<tr><td colspan="3" style="color: var(--danger); text-align: center;">Error loading directory.</td></tr>`;
    }
}

function editEmployee(empId) {
    const emp = adminEmployeesData.find(e => e.emp_id === empId);
    if (!emp) return;
    
    document.getElementById('emp_id').value = emp.emp_id;
    document.getElementById('emp_id').setAttribute('readonly', 'true');
    document.getElementById('emp_id').style.background = 'rgba(255,255,255,0.03)';
    document.getElementById('emp_id').style.cursor = 'not-allowed';
    
    document.getElementById('full_name').value = emp.full_name;
    document.getElementById('dob').value = emp.dob;
    document.getElementById('address').value = emp.address;
    document.getElementById('email').value = emp.email;
    document.getElementById('phone_number').value = emp.phone_number;
    document.getElementById('status').value = emp.status;
    document.getElementById('is_edit').value = 'true';
    
    document.getElementById('form-title').textContent = 'Edit Staff Member';
    document.getElementById('submit-btn').textContent = 'Update Employee';
    document.getElementById('cancel-edit-btn').style.display = 'inline-flex';
}

async function deleteEmployee(empId) {
    if (!confirm('Are you sure you want to delete this employee?')) return;
    try {
        const res = await fetchAPI('../backend/employees.php?action=delete', 'POST', { emp_id: empId });
        if (res.success) {
            alert(res.message);
            loadAdminEmployees();
        }
    } catch(err) {
        alert('Error: ' + err.message);
    }
}

// ADMIN SERVICE REQUESTS / APPROVALS
let adminRequestsData = [];
function initAdminRequests() {
    loadAdminRequests();
    
    const moderationForm = document.getElementById('moderation-form');
    if (moderationForm) {
        moderationForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const request_id = document.getElementById('request_id').value;
            const status = document.getElementById('status').value;
            const admin_remarks = document.getElementById('admin_remarks').value.trim();
            
            try {
                const res = await fetchAPI('../backend/requests.php?action=moderate', 'POST', {
                    request_id: parseInt(request_id), status, admin_remarks
                });
                if (res.success) {
                    showNotice('success', res.message);
                    moderationForm.reset();
                    document.getElementById('moderation-panel').style.display = 'none';
                    loadAdminRequests();
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
        
        document.getElementById('cancel-moderation').addEventListener('click', () => {
            moderationForm.reset();
            document.getElementById('moderation-panel').style.display = 'none';
        });
    }
}

async function loadAdminRequests() {
    const requestsTableBody = document.getElementById('requests-table-body');
    if (!requestsTableBody) return;
    
    try {
        const res = await fetchAPI('../backend/services.php?action=requests');
        if (res.success) {
            adminRequestsData = res.data;
            if (adminRequestsData.length > 0) {
                requestsTableBody.innerHTML = adminRequestsData.map(req => `
                    <tr id="req-row-${req.request_id}">
                        <td>
                            <strong>${escapeHTML(req.customer_name)}</strong>
                            <div style="font-size: 0.8rem; color: var(--text-secondary);">${escapeHTML(req.customer_email)}</div>
                        </td>
                        <td><strong>${escapeHTML(req.service_name)}</strong></td>
                        <td>${req.price !== null ? '$' + parseFloat(req.price).toFixed(2) : 'Quote'}</td>
                        <td style="font-size: 0.85rem; color: var(--text-secondary);">${escapeHTML(req.requested_at)}</td>
                        <td>
                            <span class="badge badge-${escapeHTML(req.status)}">
                                ${escapeHTML(req.status)}
                            </span>
                        </td>
                        <td style="font-size: 0.85rem; color: var(--text-secondary);">
                            ${req.admin_remarks ? escapeHTML(req.admin_remarks) : '<em>None</em>'}
                            ${req.approved_by_name ? `<div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.2rem;">By: ${escapeHTML(req.approved_by_name)}</div>` : ''}
                        </td>
                        <td>
                            <button onclick="reviewRequest(${req.request_id})" class="btn btn-secondary btn-sm" style="padding: 0.3rem 0.6rem;">Review</button>
                        </td>
                    </tr>
                `).join('');
            } else {
                requestsTableBody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted);">No service requests logged.</td></tr>`;
            }
        }
    } catch (e) {
        requestsTableBody.innerHTML = `<tr><td colspan="7" style="color: var(--danger); text-align: center;">Error loading log.</td></tr>`;
    }
}

function reviewRequest(id) {
    const req = adminRequestsData.find(r => r.request_id === id);
    if (!req) return;
    
    // Highlight row
    adminRequestsData.forEach(r => {
        const row = document.getElementById(`req-row-${r.request_id}`);
        if (row) row.style.background = '';
    });
    const selectedRow = document.getElementById(`req-row-${id}`);
    if (selectedRow) selectedRow.style.background = 'rgba(99, 102, 241, 0.05)';
    
    document.getElementById('moderation-panel').style.display = 'block';
    document.getElementById('req-customer').textContent = req.customer_name;
    document.getElementById('req-service').textContent = req.service_name;
    
    document.getElementById('request_id').value = req.request_id;
    document.getElementById('status').value = req.status;
    document.getElementById('admin_remarks').value = req.admin_remarks || '';
}

// ADMIN PROFILE
function initAdminProfile() {
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        // Fetch full admin details from backend profile API
        fetchAPI('../backend/profile.php')
            .then(res => {
                if (res.success && res.data) {
                    document.getElementById('full_name').value = res.data.full_name || '';
                    document.getElementById('email').value = res.data.email || '';
                    document.getElementById('mobile_number').value = res.data.mobile_number || '';
                }
            })
            .catch(err => {
                showNotice('danger', 'Error loading profile: ' + err.message);
            });
        
        profileForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const full_name = document.getElementById('full_name').value.trim();
            const email = document.getElementById('email').value.trim();
            const mobile_number = document.getElementById('mobile_number').value.trim();
            const password = document.getElementById('password').value;
            
            try {
                const res = await fetchAPI('../backend/profile.php?action=update', 'POST', {
                    full_name, email, mobile_number, password
                });
                if (res.success) {
                    showNotice('success', res.message);
                    currentUser.full_name = full_name;
                    currentUser.email = email;
                    document.querySelector('.user-tag').innerHTML = `
                        <span class="role-badge">${escapeHTML(currentUser.role)}</span>
                        ${escapeHTML(full_name)}
                    `;
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
    }
}

// CONTACT US PAGE
function initContactPage() {
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        // Auto-prefill name and email if user is logged in
        if (currentUser) {
            document.getElementById('name').value = currentUser.full_name || '';
            document.getElementById('email').value = currentUser.email || '';
        }
        
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();
            
            try {
                const res = await fetchAPI('../backend/contact.php', 'POST', {
                    name, email, subject, message
                });
                if (res.success) {
                    showNotice('success', res.message);
                    contactForm.reset();
                    if (currentUser) {
                        document.getElementById('name').value = currentUser.full_name || '';
                        document.getElementById('email').value = currentUser.email || '';
                    }
                }
            } catch (err) {
                showNotice('danger', err.message);
            }
        });
    }
}
