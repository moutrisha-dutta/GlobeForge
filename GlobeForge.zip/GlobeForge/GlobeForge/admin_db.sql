-- =========================================================
-- GlobForage Database Schema
-- Database: admin_db
-- Engine: MySQL (InnoDB)
-- Purpose: Single login for Admin & Customer, Employee lookup,
--          Service catalog, and Service request/approval workflow
-- =========================================================

CREATE DATABASE IF NOT EXISTS admin_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE admin_db;

-- ---------------------------------------------------------
-- 1. users
--    Shared login table for Admin & Customer (single login window)
--    Only 'customer' role can self-register from the frontend.
--    'admin' rows are seeded/created directly in the database.
-- ---------------------------------------------------------
CREATE TABLE users (
    user_id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    role            ENUM('admin', 'customer') NOT NULL DEFAULT 'customer',
    email           VARCHAR(150) NOT NULL,
    mobile_number   VARCHAR(20)  NOT NULL,
    full_name       VARCHAR(150) NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    status          ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_mobile (mobile_number)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 2. employees
--    Managed only by Admin (add / update / delete).
--    Looked up publicly via the homepage "Employee Verification"
--    icon using Employee ID (read-only check of info/status).
-- ---------------------------------------------------------
CREATE TABLE employees (
    emp_id          VARCHAR(20) PRIMARY KEY,          -- e.g. EMP0001 (Employee ID*)
    full_name       VARCHAR(150) NOT NULL,
    dob             DATE NOT NULL,
    address         VARCHAR(255) NOT NULL,
    email           VARCHAR(150) NOT NULL,
    phone_number    VARCHAR(20)  NOT NULL,
    status          ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_by      INT UNSIGNED NULL,                 -- admin (users.user_id) who added the record
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_employees_email (email),
    CONSTRAINT fk_employees_created_by
        FOREIGN KEY (created_by) REFERENCES users(user_id)
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 3. services
--    Managed only by Admin (add / update / delete).
--    Customers browse & choose from this list.
-- ---------------------------------------------------------
CREATE TABLE services (
    service_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    service_name    VARCHAR(150) NOT NULL,
    description     TEXT NULL,
    price           DECIMAL(10,2) NULL,
    status          ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_by      INT UNSIGNED NULL,                 -- admin (users.user_id) who added the service
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_services_created_by
        FOREIGN KEY (created_by) REFERENCES users(user_id)
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 4. service_requests
--    Created when a customer chooses a service.
--    Admin reviews/approves: pending / confirmed / successful.
-- ---------------------------------------------------------
CREATE TABLE service_requests (
    request_id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT UNSIGNED NOT NULL,             -- users.user_id (role = customer)
    service_id      INT UNSIGNED NOT NULL,
    status          ENUM('pending', 'confirmed', 'successful', 'contact_us') NOT NULL DEFAULT 'pending',
    admin_remarks   VARCHAR(255) NULL,
    approved_by     INT UNSIGNED NULL,                 -- users.user_id (role = admin)
    requested_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_requests_customer
        FOREIGN KEY (customer_id) REFERENCES users(user_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_requests_service
        FOREIGN KEY (service_id) REFERENCES services(service_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_requests_approved_by
        FOREIGN KEY (approved_by) REFERENCES users(user_id)
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- 5. contact_inquiries
--    Received customer messages from Contact Us page.
-- ---------------------------------------------------------
CREATE TABLE contact_inquiries (
    inquiry_id   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(150) NOT NULL,
    email        VARCHAR(150) NOT NULL,
    subject      VARCHAR(255) NOT NULL,
    message      TEXT NOT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Helpful indexes
-- ---------------------------------------------------------
CREATE INDEX idx_users_role        ON users(role);
CREATE INDEX idx_employees_status  ON employees(status);
CREATE INDEX idx_services_status   ON services(status);
CREATE INDEX idx_requests_status   ON service_requests(status);
CREATE INDEX idx_requests_customer ON service_requests(customer_id);
CREATE INDEX idx_requests_service  ON service_requests(service_id);

-- ---------------------------------------------------------
-- Seed: one default admin account
-- NOTE: replace the password_hash below with a real
-- password_hash() output before going live (this placeholder
-- corresponds to bcrypt hash of "Admin@123").
-- ---------------------------------------------------------
INSERT INTO users (role, email, mobile_number, full_name, password_hash, status)
VALUES (
    'admin',
    'admin@globforage.com',
    '9999999999',
    'System Administrator',
    '$2y$10$K6EktJ2waCNHSQP77YR0u.JKFSNO/SuJoxh.WRqKzguo.0BJZt60W',
    'active'
);
