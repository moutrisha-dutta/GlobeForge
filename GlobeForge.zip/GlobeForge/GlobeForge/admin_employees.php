<?php
// GlobeForge Staff Directory Configuration
// File: admin_employees.php

require_once 'config.php';
authorize(['admin']);

$error = null;
$success = null;

// Handle Delete Employee Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $emp_id = trim($_POST['emp_id'] ?? '');
    if (!empty($emp_id)) {
        try {
            $stmt = $pdo->prepare('DELETE FROM employees WHERE emp_id = ?');
            $stmt->execute([$emp_id]);
            setFlashNotice('success', 'Employee record deleted successfully.');
            header('Location: admin_employees.php');
            exit;
        } catch (PDOException $e) {
            $error = 'Failed to delete employee record: ' . $e->getMessage();
        }
    }
}

// Handle Add / Edit Employee Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    $emp_id = trim($_POST['emp_id'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone_number = trim($_POST['phone_number'] ?? '');
    $status = $_POST['status'] ?? 'active';
    $is_edit = isset($_POST['is_edit']) && $_POST['is_edit'] === 'true';

    if (empty($emp_id) || empty($full_name) || empty($dob) || empty($address) || empty($email) || empty($phone_number)) {
        $error = 'All fields are required.';
    } else {
        try {
            if ($is_edit) {
                // Edit validation: Verify email uniqueness among other records
                $check_stmt = $pdo->prepare('SELECT emp_id FROM employees WHERE email = ? AND emp_id != ? LIMIT 1');
                $check_stmt->execute([$email, $emp_id]);
                if ($check_stmt->fetch()) {
                    $error = 'Email address is already in use by another employee.';
                } else {
                    $update_stmt = $pdo->prepare('
                        UPDATE employees 
                        SET full_name = ?, dob = ?, address = ?, email = ?, phone_number = ?, status = ?
                        WHERE emp_id = ?
                    ');
                    $update_stmt->execute([$full_name, $dob, $address, $email, $phone_number, $status, $emp_id]);
                    setFlashNotice('success', 'Employee updated successfully.');
                    header('Location: admin_employees.php');
                    exit;
                }
            } else {
                // Add validation: Check unique Employee ID & Email
                $check_stmt = $pdo->prepare('SELECT emp_id, email FROM employees WHERE emp_id = ? OR email = ? LIMIT 1');
                $check_stmt->execute([$emp_id, $email]);
                $existing = $check_stmt->fetch();

                if ($existing) {
                    if ($existing['emp_id'] === $emp_id) {
                        $error = 'Employee ID is already registered.';
                    } else {
                        $error = 'Email address is already registered to another employee.';
                    }
                } else {
                    $insert_stmt = $pdo->prepare('
                        INSERT INTO employees (emp_id, full_name, dob, address, email, phone_number, status, created_by)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ');
                    $insert_stmt->execute([$emp_id, $full_name, $dob, $address, $email, $phone_number, $status, $_SESSION['user_id']]);
                    setFlashNotice('success', 'Employee registered successfully.');
                    header('Location: admin_employees.php');
                    exit;
                }
            }
        } catch (PDOException $e) {
            $error = 'Failed to save employee profile: ' . $e->getMessage();
        }
    }
}

// Fetch Active Employee Details for editing
$edit_employee = null;
if (isset($_GET['edit_id'])) {
    $edit_id = trim($_GET['edit_id']);
    try {
        $stmt = $pdo->prepare('SELECT * FROM employees WHERE emp_id = ? LIMIT 1');
        $stmt->execute([$edit_id]);
        $edit_employee = $stmt->fetch();
    } catch (PDOException $e) {
        $error = 'Failed to load employee for editing: ' . $e->getMessage();
    }
}

// Fetch all staff
$employees = [];
try {
    $stmt = $pdo->query('SELECT * FROM employees ORDER BY created_at DESC');
    $employees = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to load directory: ' . $e->getMessage();
}

$pageTitle = "Manage Directory";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <div class="dashboard-title">
        <h1>Staff Directory Configuration</h1>
        <p>Register new staff members, update deployment profile records, and control query statuses.</p>
    </div>
    <div>
        <a href="admin_dashboard.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            Back to Admin Panel
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<div class="home-grid">
    <!-- List Employees Card -->
    <div class="glass-container">
        <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">Staff Directory</h2>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Employee Details</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($employees)): ?>
                        <tr>
                            <td colspan="3" style="text-align: center; color: var(--text-muted); padding: 1.5rem 0;">No staff registered yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($employees as $emp): ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($emp['full_name']); ?></strong> <span style="color: var(--text-secondary); font-size: 0.85rem;">(ID: <?php echo e($emp['emp_id']); ?>)</span>
                                    <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 0.25rem;">
                                        Email: <?php echo e($emp['email']); ?> | Phone: <?php echo e($emp['phone_number']); ?><br>
                                        DOB: <?php echo e($emp['dob']); ?> | Address: <?php echo e($emp['address']); ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo e($emp['status']); ?>">
                                        <?php echo e($emp['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <a href="admin_employees.php?edit_id=<?php echo urlencode($emp['emp_id']); ?>" class="btn btn-secondary btn-sm" style="text-decoration: none;">Edit</a>
                                        <form method="POST" action="admin_employees.php" onsubmit="return confirm('Are you sure you want to delete this employee?');" style="margin: 0;">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="emp_id" value="<?php echo e($emp['emp_id']); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add/Edit Form Card -->
    <div class="glass-container">
        <h2 id="form-title" style="font-size: 1.5rem; margin-bottom: 1.5rem;">
            <?php echo $edit_employee ? 'Edit Employee Directory' : 'Register Employee'; ?>
        </h2>
        <form method="POST" action="admin_employees.php" autocomplete="off">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="is_edit" value="<?php echo $edit_employee ? 'true' : 'false'; ?>">
            
            <div class="form-group">
                <label for="emp_id">Employee ID *</label>
                <input type="text" name="emp_id" id="emp_id" class="form-control" placeholder="e.g. EMP0001" value="<?php echo $edit_employee ? e($edit_employee['emp_id']) : ''; ?>" <?php echo $edit_employee ? 'readonly' : ''; ?> required>
            </div>

            <div class="form-group">
                <label for="full_name">Full Name *</label>
                <input type="text" name="full_name" id="full_name" class="form-control" placeholder="Jane Doe" value="<?php echo $edit_employee ? e($edit_employee['full_name']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="dob">Date of Birth *</label>
                <input type="date" name="dob" id="dob" class="form-control" value="<?php echo $edit_employee ? e($edit_employee['dob']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="address">Address *</label>
                <input type="text" name="address" id="address" class="form-control" placeholder="123 Science Park Rd, Suite 400" value="<?php echo $edit_employee ? e($edit_employee['address']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Contact Email *</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="jane.doe@globforage.com" value="<?php echo $edit_employee ? e($edit_employee['email']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="phone_number">Contact Phone Number *</label>
                <input type="text" name="phone_number" id="phone_number" class="form-control" placeholder="555-0199" value="<?php echo $edit_employee ? e($edit_employee['phone_number']) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="status">Verification Status</label>
                <select name="status" id="status" class="form-control">
                    <option value="active" <?php echo $edit_employee && $edit_employee['status'] === 'active' ? 'selected' : ''; ?>>Active (Credentials verified)</option>
                    <option value="inactive" <?php echo $edit_employee && $edit_employee['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive (Revoked credentials)</option>
                </select>
            </div>

            <div class="d-flex gap-2" style="margin-top: 1.5rem;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">
                    <?php echo $edit_employee ? 'Update Profile' : 'Register Employee'; ?>
                </button>
                <?php if ($edit_employee): ?>
                    <a href="admin_employees.php" class="btn btn-secondary" style="flex: 1; text-align: center; text-decoration: none; line-height: 2.2;">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php
require_once 'footer.php';
?>
