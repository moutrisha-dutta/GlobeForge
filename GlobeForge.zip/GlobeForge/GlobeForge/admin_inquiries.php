<?php
// GlobeForge Contact Inquiries Moderation
// File: admin_inquiries.php

require_once 'config.php';
authorize(['admin']);

$error = null;

// Handle Delete Inquiry Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $inquiry_id = intval($_POST['inquiry_id'] ?? 0);
    if ($inquiry_id > 0) {
        try {
            $stmt = $pdo->prepare('DELETE FROM contact_inquiries WHERE inquiry_id = ?');
            $stmt->execute([$inquiry_id]);
            setFlashNotice('success', 'Contact inquiry deleted successfully.');
            header('Location: admin_inquiries.php');
            exit;
        } catch (PDOException $e) {
            $error = 'Failed to delete inquiry: ' . $e->getMessage();
        }
    }
}

// Fetch all inquiries
$inquiries = [];
try {
    $stmt = $pdo->query('SELECT * FROM contact_inquiries ORDER BY created_at DESC');
    $inquiries = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Failed to load inquiries: ' . $e->getMessage();
}

$pageTitle = "User Inquiries";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <div class="dashboard-title">
        <h1>User Inquiries Management</h1>
        <p>Review customer contact forms, read descriptions, and follow up with submissions.</p>
    </div>
    <div>
        <a href="admin_dashboard.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            Back to Admin Panel
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<div class="glass-container">
    <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">Received Contact Forms</h2>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>From Details</th>
                    <th>Subject</th>
                    <th>Message Details</th>
                    <th>Received At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($inquiries)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--text-muted); padding: 2rem 0;">No inquiries have been received yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($inquiries as $inq): ?>
                        <tr>
                            <td>
                                <strong><?php echo e($inq['name']); ?></strong>
                                <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.15rem;">
                                    <a href="mailto:<?php echo e($inq['email']); ?>" style="color: var(--primary); text-decoration: none;"><?php echo e($inq['email']); ?></a>
                                </div>
                            </td>
                            <td><strong><?php echo e($inq['subject']); ?></strong></td>
                            <td>
                                <div style="font-size: 0.9rem; color: var(--text-secondary); max-width: 350px; word-wrap: break-word; white-space: pre-line; background: rgba(255,255,255,0.03); padding: 0.75rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
                                    <?php echo e($inq['message']); ?>
                                </div>
                            </td>
                            <td><span style="font-size: 0.85rem; color: var(--text-secondary);"><?php echo e($inq['created_at']); ?></span></td>
                            <td>
                                <form method="POST" action="admin_inquiries.php" onsubmit="return confirm('Are you sure you want to delete this contact submission?');" style="margin: 0;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="inquiry_id" value="<?php echo $inq['inquiry_id']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
require_once 'footer.php';
?>
