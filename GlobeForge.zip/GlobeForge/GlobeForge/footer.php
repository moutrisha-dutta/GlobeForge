        </main>
        <footer>
            <div class="footer-content">
                <p>&copy; <?php echo date('Y'); ?> GlobeForge. All rights reserved. Premium enterprise solutions.</p>
            </div>
        </footer>
    </div>
</body>
</html>
