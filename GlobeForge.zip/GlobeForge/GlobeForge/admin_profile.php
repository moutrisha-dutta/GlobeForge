<?php
// GlobeForge Administrator Profile Settings
// File: admin_profile.php

require_once 'config.php';
authorize(['admin']);

$admin_id = $_SESSION['user_id'];
$error = null;

// Fetch current administrator details
try {
    $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ? LIMIT 1');
    $stmt->execute([$admin_id]);
    $user = $stmt->fetch();
    if (!$user) {
        setFlashNotice('danger', 'Administrator account not found.');
        header('Location: logout.php');
        exit;
    }
} catch (PDOException $e) {
    $error = 'Failed to load administrator profile: ' . $e->getMessage();
}

// Handle Update Profile Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile_number'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($full_name) || empty($email) || empty($mobile)) {
        $error = 'Full Name, Email, and Mobile Number are required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } else {
        try {
            // Check duplicates
            $stmt = $pdo->prepare('SELECT user_id, email, mobile_number FROM users WHERE (email = ? OR mobile_number = ?) AND user_id != ? LIMIT 1');
            $stmt->execute([$email, $mobile, $admin_id]);
            $existing = $stmt->fetch();
            
            if ($existing) {
                if ($existing['email'] === $email) {
                    $error = 'Email is already registered by another account.';
                } else {
                    $error = 'Mobile number is already registered by another account.';
                }
            } else {
                if (!empty($password)) {
                    if (strlen($password) < 6) {
                        $error = 'Password must be at least 6 characters.';
                    } else {
                        $pwd_hash = password_hash($password, PASSWORD_BCRYPT);
                        $stmt = $pdo->prepare('UPDATE users SET full_name = ?, email = ?, mobile_number = ?, password_hash = ? WHERE user_id = ?');
                        $stmt->execute([$full_name, $email, $mobile, $pwd_hash, $admin_id]);
                    }
                } else {
                    $stmt = $pdo->prepare('UPDATE users SET full_name = ?, email = ?, mobile_number = ? WHERE user_id = ?');
                    $stmt->execute([$full_name, $email, $mobile, $admin_id]);
                }
                
                if (!$error) {
                    $_SESSION['full_name'] = $full_name;
                    $_SESSION['email'] = $email;
                    setFlashNotice('success', 'Administrator profile updated successfully.');
                    header('Location: admin_profile.php');
                    exit;
                }
            }
        } catch (PDOException $e) {
            $error = 'Profile update failed: ' . $e->getMessage();
        }
    }
}

$pageTitle = "Admin Profile";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <div class="dashboard-title">
        <h1>Administrator Profile Settings</h1>
        <p>Modify your administrator settings, email credentials, or security password details.</p>
    </div>
    <div>
        <a href="admin_dashboard.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.5rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            Back to Admin Panel
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<div class="home-grid" style="grid-template-columns: 1.2fr 0.8fr;">
    <!-- Edit Form Card -->
    <div class="glass-container">
        <h2 style="font-size: 1.5rem; margin-bottom: 1.5rem;">Update Admin Account Details</h2>
        <form method="POST" action="admin_profile.php" autocomplete="off">
            <input type="hidden" name="action" value="update_profile">
            
            <div class="form-group">
                <label for="full_name">Full Name *</label>
                <input type="text" name="full_name" id="full_name" class="form-control" value="<?php echo e($user['full_name']); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user['email']); ?>" required>
            </div>

            <div class="form-group">
                <label for="mobile_number">Mobile Number *</label>
                <input type="text" name="mobile_number" id="mobile_number" class="form-control" value="<?php echo e($user['mobile_number']); ?>" placeholder="e.g. 9999999999" required>
            </div>

            <div class="form-group">
                <label for="password">New Password (Leave blank to keep current)</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter new password">
            </div>

            <button type="submit" class="btn btn-primary" style="margin-top: 1rem; width: 100%;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                Save Settings
            </button>
        </form>
    </div>

    <!-- Info Card -->
    <div class="glass-container d-flex flex-column justify-between" style="justify-content: space-between;">
        <div>
            <h2 style="font-size: 1.5rem; margin-bottom: 1rem;">Admin Credentials</h2>
            <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">
                Administrators are seeded in the database directly. Self-deletion is disabled to prevent losing administrative controls over the GlobeForge portal.
            </p>
            <div class="alert alert-info" style="margin-bottom: 1.5rem;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                <span>Role: SYSTEM ADMINISTRATOR</span>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'footer.php';
?>
