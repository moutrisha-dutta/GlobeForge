<?php
// GlobeForge System Administration Dashboard
// File: admin_dashboard.php

require_once 'config.php';
authorize(['admin']);

$error = null;
$metrics = [
    'customers' => 0,
    'services' => 0,
    'pending' => 0,
    'staff' => 0,
    'inquiries' => 0
];

try {
    // 1. Registered Customers
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = "customer"');
    $stmt->execute();
    $metrics['customers'] = $stmt->fetchColumn();

    // 2. Active Services
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM services WHERE status = "active"');
    $stmt->execute();
    $metrics['services'] = $stmt->fetchColumn();

    // 3. Pending Approvals
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM service_requests WHERE status = "pending"');
    $stmt->execute();
    $metrics['pending'] = $stmt->fetchColumn();

    // 4. Staff Directory
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM employees');
    $stmt->execute();
    $metrics['staff'] = $stmt->fetchColumn();

    // 5. Contact Inquiries
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM contact_inquiries');
    $stmt->execute();
    $metrics['inquiries'] = $stmt->fetchColumn();
} catch (PDOException $e) {
    $error = 'Failed to load system metrics: ' . $e->getMessage();
}

$pageTitle = "Admin Dashboard";
require_once 'header.php';
?>

<div class="dashboard-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem;">
    <div class="dashboard-title">
        <h1>System Administration Dashboard</h1>
        <p>Manage service offerings, coordinate employee directories, and moderate service requests.</p>
    </div>
    <div class="d-flex gap-2" style="display: flex; gap: 0.5rem; align-items: center;">
        <a href="index.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.25rem; font-size: 0.9rem; padding: 0.5rem 1rem;">
            View Site
        </a>
        <a href="admin_profile.php" class="btn btn-secondary" style="text-decoration: none; display: flex; align-items: center; gap: 0.25rem; font-size: 0.9rem; padding: 0.5rem 1rem;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
            Profile
        </a>
        <a href="logout.php" class="btn btn-danger" style="text-decoration: none; display: flex; align-items: center; gap: 0.25rem; font-size: 0.9rem; padding: 0.5rem 1rem; background-color: var(--danger); border-color: var(--danger); color: white;">
            Logout
        </a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger mb-2">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
        <span><?php echo e($error); ?></span>
    </div>
<?php endif; ?>

<!-- Stats Metrics Grid -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
        </div>
        <div>
            <div class="stat-value"><?php echo $metrics['customers']; ?></div>
            <div class="stat-label">Registered Customers</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon pink">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l-7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
        </div>
        <div>
            <div class="stat-value"><?php echo $metrics['services']; ?></div>
            <div class="stat-label">Active Services</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon green">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
        </div>
        <div>
            <div class="stat-value"><?php echo $metrics['pending']; ?></div>
            <div class="stat-label">Pending Approvals</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="18" y1="8" x2="23" y2="13"></line><line x1="23" y1="8" x2="18" y2="13"></line></svg>
        </div>
        <div>
            <div class="stat-value"><?php echo $metrics['staff']; ?></div>
            <div class="stat-label">Staff Directory</div>
        </div>
    </div>

    <div class="stat-card">
        <div class="stat-icon pink">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
        </div>
        <div>
            <div class="stat-value"><?php echo $metrics['inquiries']; ?></div>
            <div class="stat-label">User Inquiries</div>
        </div>
    </div>
</div>

<!-- Shortcuts Panel -->
<div class="glass-container" style="margin-top: 2rem;">
    <h2 style="font-size: 1.5rem; margin-bottom: 1.5rem;">Administration Controls</h2>
    <div class="services-grid">
        <div class="service-card">
            <div>
                <h3>Manage Services</h3>
                <p>Add new solutions, configure descriptions, status properties, and control customer catalog offerings.</p>
            </div>
            <div class="service-card-footer" style="margin-top: 1.5rem;">
                <a href="admin_services.php" class="btn btn-primary" style="width: 100%; text-decoration: none; text-align: center;">Configure Services</a>
            </div>
        </div>

        <div class="service-card">
            <div>
                <h3>Service Approvals</h3>
                <p>Track request pipelines, allocate confirmed status, and assign verification remarks for customer view.</p>
            </div>
            <div class="service-card-footer" style="margin-top: 1.5rem;">
                <a href="admin_requests.php" class="btn btn-primary" style="width: 100%; text-decoration: none; text-align: center;">Moderate Approvals</a>
            </div>
        </div>

        <div class="service-card">
            <div>
                <h3>Staff Directory</h3>
                <p>Register, update, and manage employees. Provides lookup credentials checking for the public portal.</p>
            </div>
            <div class="service-card-footer" style="margin-top: 1.5rem;">
                <a href="admin_employees.php" class="btn btn-primary" style="width: 100%; text-decoration: none; text-align: center;">Configure Directory</a>
            </div>
        </div>

        <div class="service-card">
            <div>
                <h3>User Inquiries</h3>
                <p>Read customer messages, suggestions, or custom enterprise packet requests submitted via contact page.</p>
            </div>
            <div class="service-card-footer" style="margin-top: 1.5rem;">
                <a href="admin_inquiries.php" class="btn btn-primary" style="width: 100%; text-decoration: none; text-align: center;">View Inquiries</a>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'footer.php';
?>
