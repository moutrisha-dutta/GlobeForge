<?php
// GlobeForge Contact Page & Form Handler
// File: contact.php

$pageTitle = "Contact Us";
require_once 'config.php';

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } else {
        try {
            $stmt = $pdo->prepare('INSERT INTO contact_inquiries (name, email, subject, message) VALUES (?, ?, ?, ?)');
            $stmt->execute([$name, $email, $subject, $message]);
            
            // Log to file as a secondary backup
            $logEntry = sprintf(
                "[%s] Name: %s | Email: %s | Subject: %s\nMessage: %s\n--------------------\n",
                date('Y-m-d H:i:s'), $name, $email, $subject, $message
            );
            file_put_contents(__DIR__ . '/contact_submissions.log', $logEntry, FILE_APPEND);
            
            $success = 'Thank you! Your message has been received. We will contact you soon.';
            
            // Reset form variables
            $name = $email = $subject = $message = '';
        } catch (PDOException $e) {
            $error = 'Failed to send message: ' . $e->getMessage();
        }
    }
}

require_once 'header.php';
?>

<!-- Hero Header -->
<div class="hero" style="padding: 2rem 1rem;">
    <h1>Contact GlobeForge</h1>
    <p>Have inquiries or want custom enterprise packages? Get in touch with our team today.</p>
</div>

<div class="auth-wrapper" style="max-width: 580px; margin: 1rem auto;">
    <div class="glass-container">
        <h2 style="font-size: 1.75rem; margin-bottom: 1rem; text-align: center; background: linear-gradient(to right, #ffffff, #a855f7); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Send Us A Message</h2>
        <p style="color: var(--text-secondary); text-align: center; margin-bottom: 2rem; font-size: 0.9rem;">Submit your message below. Our administrative team will verify details and reach back.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger mb-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
                <span><?php echo e($error); ?></span>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success mb-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                <span><?php echo e($success); ?></span>
            </div>
        <?php endif; ?>

        <form method="POST" action="contact.php" autocomplete="off">
            <div class="form-group">
                <label for="name">Your Name *</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="e.g. John Doe" value="<?php echo isset($name) ? e($name) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="name@example.com" value="<?php echo isset($email) ? e($email) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="subject">Subject *</label>
                <input type="text" name="subject" id="subject" class="form-control" placeholder="e.g. Requesting Custom Service Quote" value="<?php echo isset($subject) ? e($subject) : ''; ?>" required>
            </div>

            <div class="form-group">
                <label for="message">Message *</label>
                <textarea name="message" id="message" class="form-control" placeholder="Type your message details here..." required><?php echo isset($message) ? e($message) : ''; ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 0.25rem;"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
                Submit Inquiry
            </button>
        </form>
    </div>
</div>

<?php
require_once 'footer.php';
?>
